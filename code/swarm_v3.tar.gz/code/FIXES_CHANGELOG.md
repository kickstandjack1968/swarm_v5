# SwarmCoordinator v2 - Bug Fixes and Improvements

## Overview

This document details all the gaps and issues found in the original SwarmCoordinator v2 code and the fixes applied.

---

## Critical Fixes

### 1. Missing VERIFIER in Fallback Map
**Location:** `AgentExecutor._get_agent_config()` (lines ~120-135)

**Problem:** The fallback mapping for multi-model mode didn't include VERIFIER, causing it to fall back to the wrong model or error out.

**Fix:** Added VERIFIER to the fallback map:
```python
fallback_map = {
    AgentRole.ARCHITECT: 'architect',
    AgentRole.CLARIFIER: 'clarifier',
    # ... other roles ...
    AgentRole.VERIFIER: 'verifier'  # ADDED
}
```

---

### 2. Context Propagation for User Request
**Location:** `SwarmCoordinator.run_workflow()` and `_build_user_message()`

**Problem:** The user's original request wasn't consistently available to downstream agents. The architect and coder might not receive the clarified requirements.

**Fix:** 
- Initialize `user_request` in context at workflow start
- Pass `user_request` in metadata for all tasks
- Check both metadata and context when building messages

```python
# In run_workflow():
self.state["context"]["user_request"] = user_request

# In task creation:
metadata={"user_request": user_request}

# In _build_user_message():
user_request = (
    task.metadata.get('user_request') or 
    self.state["context"].get("user_request", "")
)
```

---

### 3. Custom Workflow Type Not Handled
**Location:** `SwarmCoordinator.run_workflow()` (line ~769)

**Problem:** The interactive script sends `workflow_type="custom"` but `run_workflow()` raised an error for unknown types.

**Fix:** Added explicit handling for custom workflows:
```python
elif workflow_type == "custom":
    if not self.task_queue:
        print("⚠ No tasks in custom workflow queue")
        return
```

---

### 4. Clarification Flow Not Feeding Architect
**Location:** `_handle_clarification_interactive()` and context storage

**Problem:** User answers to clarification questions weren't properly formatted or stored for the architect to use.

**Fix:** Store comprehensive clarified requirements:
```python
user_request = self.state["context"].get("user_request", task.metadata.get('user_request', ''))
clarified_req = f"ORIGINAL REQUEST:\n{user_request}\n\n"
clarified_req += f"CLARIFICATION QUESTIONS:\n{result}\n\n"
clarified_req += f"USER ANSWERS:\n{answers_text}"

self.state["context"]['clarification'] = clarified_req
self.state["context"]['user_answers'] = answers_text
```

---

### 5. No Revision Loop When Reviewer Rejects
**Location:** New method `_handle_revision_cycle()`

**Problem:** When a reviewer returned `NEEDS_REVISION`, nothing triggered a re-code cycle. The `max_iterations` config was never used.

**Fix:** Added revision cycle handling:
```python
def _handle_revision_cycle(self, review_tasks: List[Task]) -> bool:
    """Check if any review requires revision and handle the cycle."""
    needs_revision = any(
        t.metadata.get("needs_revision", False) 
        for t in review_tasks 
        if t.status == TaskStatus.COMPLETED
    )
    
    if not needs_revision:
        return False
    
    # Create and execute revision task with feedback
    revision_task = Task(
        task_id=f"T_revision_{code_task.revision_count + 1}",
        task_type="coding",
        # ... includes review feedback
    )
```

---

### 6. Security Audit Task Missing Code
**Location:** `_build_user_message()`

**Problem:** The security audit task type was `"security_audit"` but no code was passed to it for analysis.

**Fix:** Added special handling for security_audit:
```python
if task.task_type == "security_audit":
    code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
    if code_task and code_task.result:
        message_parts.append(f"\nCODE TO ANALYZE FOR SECURITY:\n{code_task.result}\n")
```

---

### 7. Documenter Not Receiving Actual Code
**Location:** `_build_user_message()`

**Problem:** The documenter received dependencies but might not get the actual code if the dependency chain didn't include it directly.

**Fix:** Explicitly include code for documentation tasks:
```python
if task.task_type == "documentation":
    code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
    if code_task and code_task.result:
        message_parts.append(f"\nACTUAL CODE TO DOCUMENT:\n{code_task.result}\n")
```

---

### 8. Empty Response Handling
**Location:** `AgentExecutor.execute_agent()`

**Problem:** If an agent returned empty/None, downstream tasks would fail without a clear error.

**Fix:** Added explicit check:
```python
if not response or not response.strip():
    raise Exception("Agent returned empty response")
```

---

### 9. Metrics Lock / Success Flag Issue
**Location:** `AgentExecutor.execute_agent()`

**Problem:** The `finally` block could run when `success` was still `False` from initialization (not from actual failure), causing incorrect metrics.

**Fix:** Initialize variables properly and ensure clean flow:
```python
success = False
tokens = 0
response = ""

try:
    response, tokens = self._call_api(...)
    if not response or not response.strip():
        raise Exception("Agent returned empty response")
    success = True
    return response
except Exception as e:
    raise Exception(f"Agent {role.value} failed: {str(e)}")
finally:
    elapsed = time.time() - start_time
    with self.metrics_lock:
        self.metrics[agent_key].update(success, elapsed, tokens)
```

---

### 10. Review Workflow Context Initialization
**Location:** `_create_review_workflow()`

**Problem:** The review workflow stored code in metadata but didn't initialize context properly.

**Fix:** Store code in context for the review workflow:
```python
def _create_review_workflow(self, code: str):
    self.state["context"]["code_to_review"] = code
    # ... rest of method
```

---

## Other Improvements

### Dataclass Default Factory
Changed from mutable defaults to `field(default_factory=...)`:
```python
@dataclass
class Task:
    dependencies: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
```

### Better Config File Search
Now searches multiple paths:
```python
paths_to_try = [
    config_file,
    os.path.join("config", config_file),
    os.path.join(os.path.dirname(__file__), config_file),
    os.path.join(os.path.dirname(__file__), "config", config_file)
]
```

### Improved Code Cleaning
Better regex patterns for extracting code from markdown:
```python
code_indicators = (
    stripped.startswith('import '),
    stripped.startswith('from '),
    stripped.startswith('class '),
    stripped.startswith('def '),
    stripped.startswith('"""'),
    stripped.startswith("'''"),
    stripped.startswith('@'),  # decorators
    stripped.startswith('#!'),  # shebang
)
```

### New TaskStatus
Added `NEEDS_REVISION` status:
```python
class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    NEEDS_REVISION = "needs_revision"  # NEW
```

### Extended Standard Library List
More comprehensive stdlib detection for requirements.txt:
```python
stdlib = {'os', 'sys', 'json', 'time', 'datetime', 'collections', 're', 
         'math', 'random', 'itertools', 'functools', 'pathlib', 'typing',
         'logging', 'argparse', 'threading', 'multiprocessing', 'copy',
         'abc', 'dataclasses', 'enum', 'io', 'string', 'textwrap',
         'unittest', 'csv', 'pickle', 'hashlib', 'base64', 'uuid',
         # ... more modules
         }
```

### Better API Error Handling
More specific exception handling:
```python
except requests.exceptions.Timeout:
    raise Exception(f"API call timed out after {timeout}s")
except requests.exceptions.RequestException as e:
    raise Exception(f"API request failed: {str(e)}")
except (KeyError, IndexError, json.JSONDecodeError) as e:
    raise Exception(f"Invalid API response format: {str(e)}")
```

---

## Usage

Replace your existing files with the fixed versions:
- `swarm_coordinator_v2_fixed.py` → rename to `swarm_coordinator_v2.py`
- `interactive_v2_fixed.py` → rename to `interactive_v2.py`

Or update your imports to use the `_fixed` versions.

```bash
# Run the interactive CLI
python interactive_v2_fixed.py

# Or import the coordinator directly
from swarm_coordinator_v2_fixed import SwarmCoordinator
coordinator = SwarmCoordinator(config_file="config_v2.json")
coordinator.run_workflow("Your request here", workflow_type="standard")
```

---

## Files Provided

1. **swarm_coordinator_v2_fixed.py** - The main coordinator with all fixes
2. **interactive_v2_fixed.py** - Updated CLI that works with the fixed coordinator
3. **config_v2.json** - Your original config (unchanged, works with fixed code)
