# Swarm Coordinator v2

Advanced multi-agent system with **automatic project organization** and versioning.

## Quick Start

```bash
# 1. Setup
bash setup.sh

# 2. Validate
python3 quickstart.py

# 3. Run
python3 interactive_v2.py
```

## What's Different: Organized Project Output

**The swarm automatically creates organized project folders:**

```
projects/
├── 001_csv_parser_v1/
│   ├── src/
│   │   └── csv_parser.py       ← Your code
│   ├── tests/
│   │   └── test_csv_parser.py  ← Generated tests
│   ├── docs/
│   │   └── README.md           ← Documentation
│   ├── PROJECT_INFO.txt        ← Project details
│   ├── REVIEW_RESULTS.txt      ← Review feedback
│   ├── requirements.txt        ← Dependencies
│   └── session_state.json      ← Full session data
│
├── 002_csv_parser_v2/          ← Improved version
│   └── [same structure]
│
└── 003_queue_manager_v1/       ← Different project
    └── [same structure]
```

**Every project gets:**
- ✅ **Unique number** (001, 002, 003...)
- ✅ **Descriptive name** (extracted from your request)
- ✅ **Version tracking** (v1, v2, v3...)
- ✅ **Proper structure** (src/, tests/, docs/)
- ✅ **All outputs organized** (no files dumped in root)

## Project Structure

```
swarm_v2/
├── src/                          # Core system modules
│   ├── swarm_coordinator_v2.py   # Main coordinator
│   └── swarm_manager.py          # Session management
├── config/                       # Configuration files
│   └── config_v2.json            # Main configuration
├── docs/                         # Documentation
│   ├── START_HERE.txt            # Quick start guide
│   ├── INDEX.txt                 # File reference
│   ├── README.md                 # Complete guide
│   ├── MIGRATION.md              # v1→v2 upgrade
│   ├── UPGRADE_SUMMARY.md        # Improvements overview
│   └── VISUAL_COMPARISON.md      # Side-by-side comparison
├── examples/                     # Example scripts
│   ├── example_simple.py         # Basic usage
│   └── example_batch_lao.py      # Batch processing
├── tests/                        # Test files (empty - add yours)
├── sessions/                     # Session state files (auto-generated)
├── logs/                         # Log files (auto-generated)
├── metrics/                      # Metrics exports (auto-generated)
├── interactive_v2.py             # Main CLI interface
├── quickstart.py                 # System validation
├── setup.sh                      # Installation script
└── .gitignore                    # Git ignore rules

```

## Key Features

- **3-4x faster** than v1 through parallel execution
- **9 specialized agent roles** (Architect, Clarifier, Coder, Reviewer, Tester, Optimizer, Documenter, Debugger, Security)
- **4 workflow types** (Standard, Full, Review, Custom)
- **Comprehensive metrics** tracking and analysis
- **Production-ready** with failure recovery and checkpointing

## Documentation

- **First time?** Read `docs/START_HERE.txt`
- **Upgrading from v1?** Read `docs/MIGRATION.md`
- **Complete reference?** Read `docs/README.md`
- **Want comparisons?** Read `docs/VISUAL_COMPARISON.md`

## Configuration

Edit `config/config_v2.json`:

1. Set your LM Studio URL (default: `http://localhost:1234/v1`)
2. Set your Ollama URL (default: `http://localhost:11434`)
3. Assign models to agent roles
4. Configure parallelism for your hardware

## Examples

### Simple Code Generation
```bash
python3 examples/example_simple.py
```

Generates:
```
projects/001_sum_even_numbers_v1/
├── src/sum_even_numbers.py
├── tests/test_sum_even_numbers.py
├── PROJECT_INFO.txt
└── REVIEW_RESULTS.txt
```

### Full Workflow (All Agents)
```bash
python3 examples/example_full_workflow.py
```

Generates complete project with code, tests, docs, and reviews.

### Project Versioning
```bash
python3 examples/example_versioning.py
```

Shows how the swarm handles iterations:
- First run: `001_csv_parser_v1/`
- Improved version: `002_csv_parser_v2/`
- Different project: `003_queue_manager_v1/`

## How Project Naming Works

**Your request:** "Create a Python script to parse CSV files with error handling"

**Project generated:** `001_python_script_parse_v1/`
- Number: `001` (auto-incremented)
- Name: `python_script_parse` (extracted from request)
- Version: `v1` (first version)

**If you improve it later:** `002_python_script_parse_v2/`
- Same base name, new version number
- Keeps history of iterations

## Usage

### Interactive Mode
```bash
python3 interactive_v2.py
```

### Programmatic Usage
```python
from src.swarm_coordinator_v2 import SwarmCoordinator

coordinator = SwarmCoordinator(config_file="config/config_v2.json")
coordinator.run_workflow("Your request here", workflow_type="standard")
```

### Session Analysis
```bash
python3 src/swarm_manager.py
```

## Performance

- **Laptop (sequential):** ~8 minutes
- **Server (parallel x4):** ~2-4 minutes
- **Batch processing:** 10x faster than v1

## Requirements

- Python 3.7+
- `requests` library
- LM Studio and/or Ollama

## Installation

```bash
bash setup.sh
```

This will:
- Check dependencies
- Create directory structure
- Set permissions
- Run validation

## Support

Check documentation in order:
1. `docs/INDEX.txt` - Quick reference
2. `docs/README.md` - Complete guide
3. Session logs in `sessions/`
4. Run `python3 src/swarm_manager.py` for analysis

## License

Proprietary - for use in petrochemical plant operations only.

---

**Version:** 2.0  
**Environment:** Air-gapped, local LLMs only  
**Platform:** Linux (Ubuntu 24)
