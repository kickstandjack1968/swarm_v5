#!/usr/bin/env python3
"""
Quick Start & System Validation
Checks your setup and runs a simple test workflow
"""

import sys
import os
import json
import requests
from datetime import datetime

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))


def print_header(text):
    """Print formatted header"""
    print("\n" + "=" * 80)
    print(f"  {text}")
    print("=" * 80 + "\n")


def check_python_version():
    """Check Python version"""
    version = sys.version_info
    print(f"Python version: {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("❌ Python 3.7+ required")
        return False
    
    print("✓ Python version OK")
    return True


def check_dependencies():
    """Check required dependencies"""
    try:
        import requests
        print(f"✓ requests library installed (version {requests.__version__})")
        return True
    except ImportError:
        print("❌ requests library not found")
        print("   Install with: pip install requests --break-system-packages")
        return False


def check_config_file():
    """Check if configuration exists"""
    if os.path.exists("config_v2.json"):
        print("✓ Found config_v2.json")
        
        try:
            with open("config_v2.json", 'r') as f:
                config = json.load(f)
            print("✓ Configuration is valid JSON")
            return config
        except json.JSONDecodeError as e:
            print(f"❌ Configuration has JSON errors: {e}")
            return None
    else:
        print("⚠ config_v2.json not found")
        print("   Creating default configuration...")
        
        # Import and create default
        from swarm_coordinator_v2 import SwarmCoordinator
        coordinator = SwarmCoordinator()
        
        with open("config_v2.json", 'w') as f:
            json.dump(coordinator.config, f, indent=2)
        
        print("✓ Created config_v2.json")
        return coordinator.config


def check_model_servers(config):
    """Check connectivity to model servers"""
    print_header("Checking Model Server Connectivity")
    
    mode = config.get('model_config', {}).get('mode', 'single')
    servers_to_check = set()
    
    if mode == 'single':
        url = config['model_config']['single_model']['url']
        servers_to_check.add(url)
    elif mode == 'multi':
        for agent, agent_config in config['model_config']['multi_model'].items():
            servers_to_check.add(agent_config['url'])
    
    results = {}
    for server_url in servers_to_check:
        print(f"\nTesting: {server_url}")
        
        # Determine server type
        if '11434' in server_url or 'ollama' in server_url.lower():
            # Ollama
            test_url = server_url.replace('/v1', '').rstrip('/') + '/api/tags'
        else:
            # OpenAI-compatible (LM Studio)
            test_url = server_url.replace('/v1', '').rstrip('/') + '/v1/models'
        
        try:
            response = requests.get(test_url, timeout=5)
            if response.status_code == 200:
                print(f"  ✓ Connected successfully")
                
                # Try to get model info
                data = response.json()
                if 'models' in data:
                    models = data['models']
                    if isinstance(models, list) and len(models) > 0:
                        print(f"  ✓ Found {len(models)} model(s)")
                        for model in models[:3]:  # Show first 3
                            name = model.get('name', model.get('id', 'unknown'))
                            print(f"     • {name}")
                    else:
                        print(f"  ⚠ No models loaded")
                
                results[server_url] = True
            else:
                print(f"  ⚠ Server responded with status {response.status_code}")
                results[server_url] = False
        except requests.exceptions.ConnectionError:
            print(f"  ❌ Connection refused - is the server running?")
            results[server_url] = False
        except requests.exceptions.Timeout:
            print(f"  ⚠ Connection timeout")
            results[server_url] = False
        except Exception as e:
            print(f"  ❌ Error: {e}")
            results[server_url] = False
    
    return results


def run_simple_test():
    """Run a simple test workflow"""
    print_header("Running Test Workflow")
    
    print("This will test the swarm with a simple request...")
    proceed = input("Run test? [Y/n]: ").strip().lower()
    
    if proceed and proceed != 'y':
        print("Test skipped")
        return
    
    try:
        from swarm_coordinator_v2 import SwarmCoordinator
        
        print("\nInitializing coordinator...")
        coordinator = SwarmCoordinator(config_file="config_v2.json")
        
        # Simple test request
        test_request = """
        Create a simple Python function that:
        1. Takes a list of numbers
        2. Returns the sum of even numbers
        3. Includes error handling for empty lists
        """
        
        print("\nTest request:")
        print(test_request)
        print("\nStarting workflow (this may take 2-5 minutes)...")
        print("=" * 80)
        
        coordinator.run_workflow(test_request, workflow_type="standard")
        
        print("\n" + "=" * 80)
        print("✓ Test completed successfully!")
        
        # Show quick summary
        metrics = coordinator.get_metrics_summary()
        print(f"\nQuick Summary:")
        print(f"  Tasks completed: {metrics['tasks']['completed']}")
        print(f"  Tasks failed: {metrics['tasks']['failed']}")
        
        total_tokens = sum(m['total_tokens'] for m in metrics['agents'].values())
        print(f"  Total tokens used: {total_tokens}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def print_summary(checks):
    """Print final summary"""
    print_header("System Check Summary")
    
    all_passed = all(checks.values())
    
    for check_name, passed in checks.items():
        status = "✓" if passed else "❌"
        print(f"{status} {check_name}")
    
    if all_passed:
        print("\n✓ All checks passed! System is ready to use.")
        print("\nNext steps:")
        print("  1. Review config_v2.json and adjust for your setup")
        print("  2. Run: python interactive_v2.py")
        print("  3. Select a workflow and start building!")
    else:
        print("\n⚠ Some checks failed. Please fix the issues above.")
        print("\nCommon fixes:")
        print("  • Start LM Studio or Ollama")
        print("  • Load a model in your LLM server")
        print("  • Update URLs in config_v2.json")
        print("  • Install dependencies")


def main():
    """Main validation flow"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                     SWARM COORDINATOR v2 - QUICK START                       ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
""")
    
    print(f"Validation started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    checks = {}
    
    # Check 1: Python version
    print_header("Checking Python Environment")
    checks["Python version"] = check_python_version()
    
    # Check 2: Dependencies
    checks["Dependencies"] = check_dependencies()
    
    if not checks["Dependencies"]:
        print_summary(checks)
        return
    
    # Check 3: Configuration
    print_header("Checking Configuration")
    config = check_config_file()
    checks["Configuration"] = config is not None
    
    if not config:
        print_summary(checks)
        return
    
    # Check 4: Model servers
    server_results = check_model_servers(config)
    checks["Model servers"] = any(server_results.values())
    
    # Print summary
    print_summary(checks)
    
    # Offer to run test
    if all(checks.values()):
        print("\n" + "=" * 80)
        run_simple_test()
    
    print("\n" + "=" * 80)
    print("For full documentation, see:")
    print("  • README.md - Complete usage guide")
    print("  • MIGRATION.md - Upgrade from v1")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠ Interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
