"""Flask API routes with swarm integration."""
from flask import Flask, request, jsonify, Response, render_template
import uuid
import json
from pathlib import Path
from ..orchestrator.orchestrator import get_orchestrator
from ..database.session_db import SessionDB
from ..rag.ingestion import ingest_file
from ..rag.retriever import get_retriever
from ..swarm.swarm_service import get_swarm_service, SwarmTaskType, SwarmStatus
from ..utils.logger import app_logger


def create_app():
    app = Flask(__name__, 
                static_folder='../../static',
                template_folder='../../static')
    
    orchestrator = get_orchestrator()
    session_db = SessionDB()
    retriever = get_retriever()
    swarm_service = get_swarm_service()
    
    # ========================================================================
    # EXISTING ROUTES
    # ========================================================================
    
    @app.route('/')
    def index():
        return render_template('index.html')
    
    @app.route('/api/sessions', methods=['GET', 'POST'])
    def sessions():
        if request.method == 'GET':
            sessions = session_db.list_sessions(limit=50)
            return jsonify(sessions)
        else:
            data = request.json
            session_id = session_db.create_session(name=data.get('name', 'New Chat'))
            return jsonify({'id': session_id})
    
    @app.route('/api/sessions/<session_id>', methods=['GET', 'PUT', 'DELETE'])
    def session_detail(session_id):
        if request.method == 'GET':
            session = session_db.get_session(session_id)
            return jsonify(session) if session else ('', 404)
        elif request.method == 'PUT':
            data = request.json
            session_db.update_session(session_id, **data)
            return jsonify({'status': 'updated'})
        else:
            session_db.delete_session(session_id)
            return jsonify({'status': 'deleted'})
    
    @app.route('/api/chat', methods=['POST'])
    def chat():
        """
        Main chat endpoint - now with swarm detection.
        
        If the query matches swarm intent and files are present,
        suggests swarm execution. Otherwise, normal chat flow.
        """
        data = request.json
        query = data.get('query')
        session_id = data.get('session_id')
        files = data.get('files', [])  # List of file paths from previous uploads
        force_swarm = data.get('force_swarm', False)
        
        if not query or not session_id:
            return jsonify({'error': 'Missing query or session_id'}), 400
        
        # Convert file paths to Path objects
        file_paths = [Path(f) for f in files] if files else None
        
        # Check if this should be a swarm task
        if force_swarm or swarm_service.should_use_swarm(query, file_paths):
            # Return suggestion to use swarm
            task_type = swarm_service.intent_detector.detect_intent(query, file_paths)
            confidence = swarm_service.intent_detector.get_confidence(query, file_paths)
            
            return jsonify({
                'swarm_suggested': True,
                'task_type': task_type.value if task_type else 'general',
                'confidence': confidence,
                'message': f"This looks like a complex task that could benefit from the coding swarm. "
                          f"Would you like to use the multi-agent system? (Task type: {task_type.value if task_type else 'general'})"
            })
        
        # Normal chat flow
        def generate():
            for chunk in orchestrator.process_query(query, session_id, stream=True):
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"
            yield "data: [DONE]\n\n"
        
        return Response(generate(), mimetype='text/event-stream')
    
    @app.route('/api/upload', methods=['POST'])
    def upload():
        """
        File upload endpoint - enhanced to track files for swarm.
        """
        if 'file' not in request.files:
            return jsonify({'error': 'No file'}), 400
        
        file = request.files['file']
        upload_dir = Path(__file__).parent.parent.parent / 'data' / 'uploads'
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        file_path = upload_dir / file.filename
        file.save(str(file_path))
        
        # Check file extension for swarm-relevant files
        swarm_extensions = ['.xlsx', '.xls', '.csv', '.json', '.xml']
        is_swarm_relevant = file_path.suffix.lower() in swarm_extensions
        
        try:
            # Ingest for RAG if it's a document type
            rag_extensions = ['.txt', '.md', '.pdf', '.docx', '.html']
            if file_path.suffix.lower() in rag_extensions:
                chunks = ingest_file(file_path)
                document_id = str(uuid.uuid4())
                retriever.add_chunks(chunks, document_id)
                rag_processed = True
                chunk_count = len(chunks)
            else:
                rag_processed = False
                document_id = None
                chunk_count = 0
            
            return jsonify({
                'status': 'success',
                'file_path': str(file_path),
                'filename': file.filename,
                'document_id': document_id,
                'chunks': chunk_count,
                'rag_processed': rag_processed,
                'swarm_relevant': is_swarm_relevant
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    # ========================================================================
    # SWARM ROUTES
    # ========================================================================
    
    @app.route('/api/swarm/tasks', methods=['GET', 'POST'])
    def swarm_tasks():
        """
        List or create swarm tasks.
        
        GET: List all tasks (optional ?status=pending|running|completed|failed)
        POST: Create new task
        """
        if request.method == 'GET':
            status_filter = request.args.get('status')
            if status_filter:
                try:
                    status = SwarmStatus(status_filter)
                except ValueError:
                    return jsonify({'error': f'Invalid status: {status_filter}'}), 400
            else:
                status = None
            
            tasks = swarm_service.list_tasks(status)
            return jsonify({
                'tasks': [
                    {
                        'task_id': t.task_id,
                        'task_type': t.task_type.value,
                        'description': t.description[:100] + '...' if len(t.description) > 100 else t.description,
                        'status': t.status.value,
                        'created_at': t.created_at.isoformat(),
                        'started_at': t.started_at.isoformat() if t.started_at else None,
                        'completed_at': t.completed_at.isoformat() if t.completed_at else None,
                        'output_path': str(t.output_path) if t.output_path else None,
                        'error': t.error
                    }
                    for t in tasks
                ]
            })
        
        else:  # POST
            data = request.json
            description = data.get('description')
            
            if not description:
                return jsonify({'error': 'Missing description'}), 400
            
            # Optional parameters
            task_type_str = data.get('task_type')
            task_type = SwarmTaskType(task_type_str) if task_type_str else None
            files = [Path(f) for f in data.get('files', [])]
            parameters = data.get('parameters', {})
            
            task = swarm_service.create_task(
                description=description,
                task_type=task_type,
                files=files,
                parameters=parameters
            )
            
            return jsonify({
                'task_id': task.task_id,
                'task_type': task.task_type.value,
                'status': task.status.value,
                'message': 'Task created. Use /api/swarm/tasks/{task_id}/execute to run.'
            })
    
    @app.route('/api/swarm/tasks/<task_id>', methods=['GET', 'DELETE'])
    def swarm_task_detail(task_id):
        """
        Get or cancel a specific task.
        """
        task = swarm_service.get_task(task_id)
        if not task:
            return jsonify({'error': 'Task not found'}), 404
        
        if request.method == 'GET':
            return jsonify({
                'task_id': task.task_id,
                'task_type': task.task_type.value,
                'description': task.description,
                'status': task.status.value,
                'files': [str(f) for f in task.files],
                'parameters': task.parameters,
                'created_at': task.created_at.isoformat(),
                'started_at': task.started_at.isoformat() if task.started_at else None,
                'completed_at': task.completed_at.isoformat() if task.completed_at else None,
                'output_path': str(task.output_path) if task.output_path else None,
                'error': task.error,
                'progress': task.progress
            })
        
        else:  # DELETE (cancel)
            success = swarm_service.cancel_task(task_id)
            if success:
                return jsonify({'status': 'cancelled', 'task_id': task_id})
            else:
                return jsonify({'error': 'Cannot cancel task in current state'}), 400
    
    @app.route('/api/swarm/tasks/<task_id>/execute', methods=['POST'])
    def execute_swarm_task(task_id):
        """
        Execute a swarm task with streaming progress.
        
        Returns Server-Sent Events with progress updates.
        """
        task = swarm_service.get_task(task_id)
        if not task:
            return jsonify({'error': 'Task not found'}), 404
        
        if task.status != SwarmStatus.PENDING:
            return jsonify({'error': f'Task is {task.status.value}, not pending'}), 400
        
        def generate():
            for progress in swarm_service.execute_task(task_id):
                yield f"data: {json.dumps(progress)}\n\n"
            yield "data: [DONE]\n\n"
        
        return Response(generate(), mimetype='text/event-stream')
    
    @app.route('/api/swarm/quick', methods=['POST'])
    def swarm_quick():
        """
        Quick swarm execution - create and run in one call.
        
        Combines task creation and execution for simpler use.
        """
        data = request.json
        description = data.get('description')
        
        if not description:
            return jsonify({'error': 'Missing description'}), 400
        
        # Create task
        task_type_str = data.get('task_type')
        task_type = SwarmTaskType(task_type_str) if task_type_str else None
        files = [Path(f) for f in data.get('files', [])]
        parameters = data.get('parameters', {})
        
        task = swarm_service.create_task(
            description=description,
            task_type=task_type,
            files=files,
            parameters=parameters
        )
        
        # Execute with streaming
        def generate():
            yield f"data: {json.dumps({'task_id': task.task_id, 'status': 'created'})}\n\n"
            
            for progress in swarm_service.execute_task(task.task_id):
                yield f"data: {json.dumps(progress)}\n\n"
            
            yield "data: [DONE]\n\n"
        
        return Response(generate(), mimetype='text/event-stream')
    
    @app.route('/api/swarm/detect', methods=['POST'])
    def detect_swarm_intent():
        """
        Detect if a query should use the swarm.
        
        Useful for UI to decide whether to show swarm option.
        """
        data = request.json
        query = data.get('query', '')
        files = [Path(f) for f in data.get('files', [])]
        
        task_type = swarm_service.intent_detector.detect_intent(query, files)
        confidence = swarm_service.intent_detector.get_confidence(query, files)
        should_use = swarm_service.should_use_swarm(query, files)
        
        return jsonify({
            'should_use_swarm': should_use,
            'task_type': task_type.value if task_type else None,
            'confidence': confidence
        })
    
    @app.route('/api/swarm/status', methods=['GET'])
    def swarm_status():
        """
        Get overall swarm service status.
        """
        tasks = swarm_service.list_tasks()
        
        return jsonify({
            'enabled': swarm_service.config.get('enabled', True),
            'total_tasks': len(tasks),
            'pending': len([t for t in tasks if t.status == SwarmStatus.PENDING]),
            'running': len([t for t in tasks if t.status == SwarmStatus.RUNNING]),
            'completed': len([t for t in tasks if t.status == SwarmStatus.COMPLETED]),
            'failed': len([t for t in tasks if t.status == SwarmStatus.FAILED])
        })
    
    return app
