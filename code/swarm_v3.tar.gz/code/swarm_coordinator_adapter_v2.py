"""
SwarmCoordinator Adapter - Integrates SwarmCoordinator v2 with Local AI Assistant.

This adapter bridges the gap between the chat-based SwarmService and your
SwarmCoordinator v2, handling:
- Task translation between systems
- Progress callback streaming
- File handling for data tasks
- Workflow selection based on task type
"""

import os
import sys
import json
import time
from pathlib import Path
from typing import Dict, Any, List, Iterator, Callable, Optional
from dataclasses import dataclass
from threading import Thread
from queue import Queue

# Import your SwarmCoordinator v2
# Adjust this path based on where swarm_coordinator_v2.py lives
try:
    from swarm_coordinator_v2 import (
        SwarmCoordinator, 
        AgentRole, 
        TaskStatus, 
        Task
    )
    SWARM_AVAILABLE = True
except ImportError:
    SWARM_AVAILABLE = False
    print("Warning: swarm_coordinator_v2 not found. Swarm functionality disabled.")


@dataclass
class SwarmProgress:
    """Progress update from swarm execution."""
    agent: str
    status: str
    message: str
    task_id: str = ""
    artifacts: List[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': 'agent_progress',
            'agent': self.agent,
            'status': self.status,
            'message': self.message,
            'task_id': self.task_id,
            'artifacts': self.artifacts or []
        }


class SwarmCoordinatorAdapter:
    """
    Adapter to integrate SwarmCoordinator v2 with the Local AI Assistant.
    
    This class wraps your existing SwarmCoordinator and provides:
    - A standardized interface for the chat system
    - Progress streaming via callbacks
    - Task type mapping to workflow types
    - File handling for data-centric tasks
    """
    
    # Map chat task types to SwarmCoordinator workflow types
    WORKFLOW_MAP = {
        'excel_to_db': 'standard',      # Uses clarify -> architect -> code -> review -> document
        'code_project': 'standard',      # Same workflow, different context
        'data_pipeline': 'standard',
        'document_parser': 'standard',
        'api_builder': 'full',           # Uses full workflow with testing and optimization
        'general': 'standard'
    }
    
    def __init__(self, config: Dict[str, Any], config_file: str = "config_v2.json"):
        """
        Initialize the adapter.
        
        Args:
            config: Configuration from swarm.yaml (chat system config)
            config_file: Path to SwarmCoordinator v2 config file
        """
        self.chat_config = config
        self.config_file = config_file
        self._coordinator = None
        self._progress_queue = Queue()
        
        # Override projects root if specified in chat config
        self.projects_root = config.get('output', {}).get('projects_root', 'projects')
    
    @property
    def coordinator(self) -> 'SwarmCoordinator':
        """Lazy-load the SwarmCoordinator."""
        if self._coordinator is None:
            if not SWARM_AVAILABLE:
                raise RuntimeError(
                    "SwarmCoordinator v2 not available. "
                    "Ensure swarm_coordinator_v2.py is in the Python path."
                )
            self._coordinator = SwarmCoordinator(self.config_file)
            self._coordinator.projects_root = self.projects_root
        return self._coordinator
    
    def run_swarm(
        self,
        task: str,
        files: List[str],
        output_dir: str,
        workflow: str = 'general',
        progress_callback: Optional[Callable] = None
    ) -> Dict[str, Any]:
        """
        Run the swarm on a task.
        
        Args:
            task: Task description from user
            files: List of file paths to process
            output_dir: Directory for output files (may be overridden by coordinator)
            workflow: Workflow type from chat system
            progress_callback: Callback for progress updates
                              Called as: callback(agent_name, status, message, artifacts)
        
        Returns:
            Dict with:
                - output_path: Path to project directory
                - files_created: List of created files
                - success: Boolean success status
                - summary: Summary of what was done
        """
        # Reset coordinator for fresh run
        self._coordinator = None
        coordinator = self.coordinator
        
        # Build enhanced task description with file context
        enhanced_task = self._build_task_with_files(task, files, workflow)
        
        # Select workflow type
        swarm_workflow = self.WORKFLOW_MAP.get(workflow, 'standard')
        
        # Setup progress monitoring if callback provided
        if progress_callback:
            self._setup_progress_monitoring(progress_callback)
        
        try:
            # Report start
            if progress_callback:
                progress_callback('coordinator', 'started', f'Starting {swarm_workflow} workflow')
            
            # Run the swarm workflow
            coordinator.run_workflow(enhanced_task, workflow_type=swarm_workflow)
            
            # Get results
            project_dir = coordinator.state.get('project_info', {}).get('project_dir', output_dir)
            
            # Collect created files
            files_created = self._get_created_files(project_dir)
            
            # Generate summary
            summary = self._generate_summary(coordinator, project_dir)
            
            # Report completion
            if progress_callback:
                progress_callback('coordinator', 'complete', summary, files_created)
            
            return {
                'output_path': project_dir,
                'files_created': files_created,
                'success': True,
                'summary': summary,
                'metrics': coordinator.get_metrics_summary()
            }
            
        except Exception as e:
            if progress_callback:
                progress_callback('coordinator', 'error', str(e))
            
            return {
                'output_path': output_dir,
                'files_created': [],
                'success': False,
                'summary': f'Swarm execution failed: {str(e)}',
                'error': str(e)
            }
    
    def _build_task_with_files(self, task: str, files: List[str], workflow: str) -> str:
        """Build enhanced task description with file context."""
        parts = [task]
        
        if files:
            parts.append("\n\n## Input Files")
            
            for file_path in files:
                path = Path(file_path)
                if path.exists():
                    parts.append(f"\n### {path.name}")
                    
                    # Add file info based on type
                    if path.suffix.lower() in ['.xlsx', '.xls']:
                        parts.append(self._describe_excel_file(path))
                    elif path.suffix.lower() == '.csv':
                        parts.append(self._describe_csv_file(path))
                    elif path.suffix.lower() == '.json':
                        parts.append(self._describe_json_file(path))
                    else:
                        parts.append(f"File: {path.name} ({path.stat().st_size} bytes)")
        
        # Add workflow-specific instructions
        if workflow == 'excel_to_db':
            parts.append("\n\n## Task Requirements")
            parts.append("1. Analyze the Excel file structure")
            parts.append("2. Design appropriate SQLite database schema")
            parts.append("3. Create Python code to parse Excel and populate database")
            parts.append("4. Include proper error handling and data validation")
            parts.append("5. Create a README with usage instructions")
        
        return '\n'.join(parts)
    
    def _describe_excel_file(self, path: Path) -> str:
        """Generate description of Excel file structure."""
        try:
            import pandas as pd
            
            xl = pd.ExcelFile(path)
            desc = [f"Excel file with {len(xl.sheet_names)} sheet(s): {', '.join(xl.sheet_names)}"]
            
            for sheet in xl.sheet_names[:3]:  # Limit to first 3 sheets
                df = xl.parse(sheet, nrows=5)
                desc.append(f"\nSheet '{sheet}':")
                desc.append(f"  Columns: {', '.join(df.columns.astype(str))}")
                desc.append(f"  Sample rows: {len(df)}")
                
                # Infer types
                types = df.dtypes.to_dict()
                desc.append(f"  Types: {dict((str(k), str(v)) for k, v in types.items())}")
            
            return '\n'.join(desc)
            
        except ImportError:
            return f"Excel file: {path.name} (pandas not available for analysis)"
        except Exception as e:
            return f"Excel file: {path.name} (analysis failed: {e})"
    
    def _describe_csv_file(self, path: Path) -> str:
        """Generate description of CSV file structure."""
        try:
            import pandas as pd
            
            df = pd.read_csv(path, nrows=5)
            desc = [f"CSV file with {len(df.columns)} columns"]
            desc.append(f"Columns: {', '.join(df.columns.astype(str))}")
            desc.append(f"Types: {dict((str(k), str(v)) for k, v in df.dtypes.to_dict().items())}")
            
            return '\n'.join(desc)
            
        except ImportError:
            return f"CSV file: {path.name}"
        except Exception as e:
            return f"CSV file: {path.name} (analysis failed: {e})"
    
    def _describe_json_file(self, path: Path) -> str:
        """Generate description of JSON file structure."""
        try:
            with open(path, 'r') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                return f"JSON array with {len(data)} items"
            elif isinstance(data, dict):
                return f"JSON object with keys: {', '.join(list(data.keys())[:10])}"
            else:
                return f"JSON file: {type(data).__name__}"
                
        except Exception as e:
            return f"JSON file: {path.name} (analysis failed: {e})"
    
    def _setup_progress_monitoring(self, callback: Callable):
        """
        Setup progress monitoring for the swarm.
        
        Note: SwarmCoordinator v2 prints progress to stdout.
        For real-time progress, we'd need to modify the coordinator
        or capture stdout. For now, we provide key checkpoints.
        """
        # The coordinator prints progress - in a full integration,
        # we could redirect stdout or add hooks to the coordinator.
        # For now, progress is reported at key points in run_swarm().
        pass
    
    def _get_created_files(self, project_dir: str) -> List[str]:
        """Get list of files created in project directory."""
        files = []
        if project_dir and os.path.exists(project_dir):
            for root, dirs, filenames in os.walk(project_dir):
                for filename in filenames:
                    full_path = os.path.join(root, filename)
                    rel_path = os.path.relpath(full_path, project_dir)
                    files.append(rel_path)
        return files
    
    def _generate_summary(self, coordinator: 'SwarmCoordinator', project_dir: str) -> str:
        """Generate summary of swarm execution."""
        metrics = coordinator.get_metrics_summary()
        
        total_tasks = metrics.get('tasks', {}).get('total', 0)
        completed = metrics.get('tasks', {}).get('completed', 0)
        failed = metrics.get('tasks', {}).get('failed', 0)
        
        files = self._get_created_files(project_dir)
        
        summary_parts = [
            f"Completed {completed}/{total_tasks} tasks",
            f"Created {len(files)} files in {os.path.basename(project_dir)}"
        ]
        
        if failed > 0:
            summary_parts.append(f"({failed} tasks failed)")
        
        # Add key output files
        key_files = [f for f in files if f.endswith(('.py', '.md', '.txt'))]
        if key_files:
            summary_parts.append(f"Key outputs: {', '.join(key_files[:5])}")
        
        return '. '.join(summary_parts)
    
    def run_swarm_streaming(
        self,
        task: str,
        files: List[str],
        output_dir: str,
        workflow: str = 'general'
    ) -> Iterator[Dict[str, Any]]:
        """
        Run swarm with streaming progress updates.
        
        Yields progress dictionaries suitable for SSE streaming.
        """
        result_holder = {'result': None, 'error': None}
        progress_queue = Queue()
        
        def progress_callback(agent: str, status: str, message: str, artifacts: List[str] = None):
            progress_queue.put({
                'type': 'agent_progress',
                'agent': agent,
                'status': status,
                'message': message,
                'artifacts': artifacts or []
            })
        
        def run_in_thread():
            try:
                result = self.run_swarm(task, files, output_dir, workflow, progress_callback)
                result_holder['result'] = result
            except Exception as e:
                result_holder['error'] = str(e)
            finally:
                progress_queue.put(None)  # Signal completion
        
        # Start swarm in background thread
        thread = Thread(target=run_in_thread)
        thread.start()
        
        # Yield progress updates
        while True:
            try:
                progress = progress_queue.get(timeout=0.5)
                if progress is None:
                    break
                yield progress
            except:
                # Check if thread is still alive
                if not thread.is_alive():
                    break
                continue
        
        # Wait for thread to complete
        thread.join(timeout=5)
        
        # Yield final result
        if result_holder['error']:
            yield {
                'type': 'error',
                'error': result_holder['error']
            }
        elif result_holder['result']:
            yield {
                'type': 'complete',
                'result': result_holder['result']
            }


# ============================================================================
# DATA ANALYST AGENT EXTENSION
# ============================================================================
# To handle Excel-to-DB tasks properly, we can extend the swarm with a
# specialized data analyst prompt. This would be added to SwarmCoordinator v2.

DATA_ANALYST_PROMPT = """You are a Data Analyst agent specializing in database schema design.

Your task is to analyze data files and design optimal database schemas.

For Excel/CSV files, you should:
1. Identify all columns and their data types
2. Detect primary key candidates (unique identifiers)
3. Identify potential foreign key relationships between sheets/tables
4. Recommend appropriate SQLite column types
5. Suggest indexes for commonly queried columns
6. Note any data quality issues (nulls, inconsistent formats)

Output your analysis as a structured schema design that the Coder can implement.

Format your output as:
```
TABLE: table_name
  - column_name: TYPE [PRIMARY KEY] [NOT NULL] [UNIQUE]
  - column_name: TYPE [REFERENCES other_table(column)]
  INDEX: column_name [, column_name]
```
"""


def create_swarm_coordinator(config: Dict[str, Any]) -> SwarmCoordinatorAdapter:
    """
    Factory function to create a SwarmCoordinator adapter.
    
    This is called by SwarmService when it needs the coordinator.
    """
    config_file = config.get('general', {}).get('swarm_config_file', 'config_v2.json')
    return SwarmCoordinatorAdapter(config, config_file)


# ============================================================================
# USAGE EXAMPLE
# ============================================================================
if __name__ == "__main__":
    # Example usage
    config = {
        'general': {
            'enabled': True,
            'swarm_config_file': 'config_v2.json'
        },
        'output': {
            'projects_root': 'projects'
        }
    }
    
    adapter = SwarmCoordinatorAdapter(config)
    
    # Example: Convert Excel to database
    result = adapter.run_swarm(
        task="Create a SQLite database from the uploaded Excel file with proper schema",
        files=["data/uploads/inventory.xlsx"],
        output_dir="output",
        workflow="excel_to_db",
        progress_callback=lambda a, s, m, art=None: print(f"[{a}] {s}: {m}")
    )
    
    print(f"\nResult: {result}")
