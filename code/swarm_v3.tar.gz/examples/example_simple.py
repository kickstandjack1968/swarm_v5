#!/usr/bin/env python3
"""
Example: Simple code generation workflow
Demonstrates basic usage of the swarm coordinator
"""

import sys
sys.path.insert(0, 'src')

from swarm_coordinator_v2 import SwarmCoordinator

def main():
    print("=" * 80)
    print("EXAMPLE: Simple Code Generation")
    print("=" * 80)
    
    # Initialize coordinator
    coordinator = SwarmCoordinator(config_file="config/config_v2.json")
    
    # Simple request
    request = """
    Create a Python function that:
    1. Takes a list of numbers
    2. Returns the sum of even numbers
    3. Includes error handling for empty lists
    4. Includes docstring and type hints
    """
    
    print("\nRequest:")
    print(request)
    print("\nRunning standard workflow...")
    print("=" * 80)
    
    # Run workflow
    coordinator.run_workflow(request, workflow_type="standard")
    
    # Save outputs
    print("\nSaving outputs...")
    
    code_task = next((t for t in coordinator.completed_tasks 
                     if t.task_type == "coding"), None)
    
    if code_task and code_task.result:
        with open("generated_code.txt", 'w') as f:
            f.write(code_task.result)
        print("✓ Code saved to: generated_code.txt")
    
    print("\n✓ Example complete!")


if __name__ == "__main__":
    main()
