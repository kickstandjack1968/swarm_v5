#!/usr/bin/env python3
"""
Example: Custom workflow with specific requirements
Build a complete Python module with full testing
"""

import sys
sys.path.insert(0, 'src')

from swarm_coordinator_v2 import SwarmCoordinator

def main():
    print("=" * 80)
    print("EXAMPLE: Custom Workflow - Complete Python Module")
    print("=" * 80)
    
    # Initialize coordinator
    coordinator = SwarmCoordinator(config_file="config/config_v2.json")
    
    # Request with specific requirements
    request = """
    Create a Python module for managing a FIFO queue with these features:
    
    1. Thread-safe operations (put, get)
    2. Maximum capacity with blocking when full
    3. Timeout support for blocking operations
    4. Statistics tracking:
       - Total items processed
       - Current queue size
       - Average wait time
    5. Proper error handling
    6. Full docstrings and type hints
    
    The module should be production-ready with comprehensive tests.
    """
    
    print("\nRequest:")
    print(request)
    print("\nRunning FULL workflow (all agents)...")
    print("=" * 80)
    
    # Run full workflow (uses all agents)
    coordinator.run_workflow(request, workflow_type="full")
    
    # Get project info
    project_info = coordinator.state.get("project_info", {})
    project_dir = project_info.get("project_dir")
    
    print("\n" + "=" * 80)
    print("WORKFLOW COMPLETE")
    print("=" * 80)
    
    if project_dir:
        print(f"\n📁 Project Location: {project_dir}")
        print(f"   Project #{project_info['project_number']:03d}")
        print(f"   Version: {project_info['version']}")
        print("\nGenerated files:")
        print("   • src/      - Your module code")
        print("   • tests/    - Comprehensive test suite")
        print("   • docs/     - Documentation")
        print("   • PROJECT_INFO.txt - Project details")
    
    print("\n✓ Example complete!")


if __name__ == "__main__":
    main()
