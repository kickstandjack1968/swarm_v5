#!/usr/bin/env python3
"""
Interactive CLI for Advanced Swarm Coordinator v2
Enhanced interface with workflow selection and real-time monitoring
"""

import sys
import os
import json
from swarm_coordinator_v2 import SwarmCoordinator, Task, AgentRole, TaskStatus


def print_banner():
    """Print welcome banner"""
    banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                   ADVANCED MULTI-AGENT SWARM v2.0                            ║
║                                                                              ║
║  Parallel Execution • Dynamic Routing • Enhanced Observability              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    print(banner)
    
    print("\n🤖 Available Agent Roles:")
    print("   • ARCHITECT    - System design and architecture")
    print("   • CLARIFIER    - Requirements clarification")
    print("   • CODER        - Code implementation")
    print("   • REVIEWER     - Code review and quality")
    print("   • TESTER       - Test generation")
    print("   • OPTIMIZER    - Performance optimization")
    print("   • DOCUMENTER   - Documentation generation")
    print("   • DEBUGGER     - Bug analysis and fixes")
    print("   • SECURITY     - Security analysis")
    print("\n" + "=" * 80 + "\n")


def get_multiline_input(prompt: str) -> str:
    """Get multiline input from user"""
    print(prompt)
    print("(Type your input. Enter 'END' on a new line when done)")
    print("-" * 80)
    
    lines = []
    while True:
        try:
            line = input()
            if line.strip().upper() == 'END':
                break
            lines.append(line)
        except EOFError:
            break
    
    return '\n'.join(lines)


def select_workflow() -> str:
    """Let user select workflow type"""
    print("\n📋 Select Workflow Type:")
    print("   1. STANDARD  - Clarify → Architect → Code → Review (Fast, 3 reviewers)")
    print("   2. FULL      - Complete pipeline with all agents (Comprehensive)")
    print("   3. REVIEW    - Review existing code (4 parallel reviews)")
    print("   4. CUSTOM    - Build custom workflow")
    
    while True:
        choice = input("\nYour choice [1-4]: ").strip()
        if choice == '1':
            return 'standard'
        elif choice == '2':
            return 'full'
        elif choice == '3':
            return 'review_only'
        elif choice == '4':
            return 'custom'
        else:
            print("❌ Invalid choice. Please enter 1-4.")


def configure_custom_workflow(coordinator: SwarmCoordinator):
    """Allow user to build custom workflow"""
    print("\n🔧 Custom Workflow Builder")
    print("=" * 80)
    
    tasks = []
    task_counter = 1
    
    print("\nAvailable agent roles:")
    for i, role in enumerate(AgentRole, 1):
        print(f"   {i}. {role.value}")
    
    while True:
        print(f"\n--- Task #{task_counter} ---")
        
        # Get role
        role_input = input("Select agent role (1-9) or 'done' to finish: ").strip()
        if role_input.lower() == 'done':
            break
        
        try:
            role_idx = int(role_input) - 1
            role = list(AgentRole)[role_idx]
        except (ValueError, IndexError):
            print("❌ Invalid role. Try again.")
            continue
        
        # Get description
        description = input(f"Task description for {role.value}: ").strip()
        if not description:
            description = f"Task for {role.value}"
        
        # Get priority
        priority = input("Priority (1-10, default 5): ").strip()
        priority = int(priority) if priority.isdigit() else 5
        
        # Get dependencies
        if tasks:
            print(f"\nExisting tasks: {', '.join([t['task_id'] for t in tasks])}")
            deps = input("Dependencies (comma-separated task IDs, or empty): ").strip()
            dependencies = [d.strip() for d in deps.split(',')] if deps else []
        else:
            dependencies = []
        
        task_id = f"T{task_counter:03d}_{role.value}"
        tasks.append({
            'task_id': task_id,
            'role': role,
            'description': description,
            'priority': priority,
            'dependencies': dependencies
        })
        
        print(f"✓ Added task: {task_id}")
        task_counter += 1
    
    # Add tasks to coordinator
    for task_info in tasks:
        coordinator.add_task(Task(
            task_id=task_info['task_id'],
            task_type=task_info['role'].value,
            description=task_info['description'],
            assigned_role=task_info['role'],
            status=TaskStatus.PENDING,
            priority=task_info['priority'],
            dependencies=task_info['dependencies']
        ))
    
    print(f"\n✓ Custom workflow created with {len(tasks)} tasks")


def check_configuration():
    """Check and display configuration"""
    config_file = "config_v2.json"
    
    if not os.path.exists(config_file):
        print(f"⚠ Warning: {config_file} not found")
        print("Creating default configuration...")
        
        # Create default config
        coordinator = SwarmCoordinator()
        with open(config_file, 'w') as f:
            json.dump(coordinator.config, f, indent=2)
        
        print(f"✓ Created {config_file}")
        return True
    
    print(f"✓ Found {config_file}")
    
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    mode = config.get('model_config', {}).get('mode', 'single')
    print(f"   Mode: {mode}")
    
    if mode == 'multi':
        print("   Multi-model configuration:")
        for agent, info in config['model_config']['multi_model'].items():
            model_name = info.get('model_name', info.get('model', 'Unknown'))
            url = info.get('url', 'Unknown')
            api_type = info.get('api_type', 'Unknown')
            print(f"      • {agent:12s}: {model_name:40s} ({api_type})")
    
    # Show parallel settings
    workflow = config.get('workflow', {})
    parallel_enabled = workflow.get('enable_parallel', False)
    max_parallel = workflow.get('max_parallel_agents', 4)
    print(f"   Parallel execution: {'Enabled' if parallel_enabled else 'Disabled'}")
    if parallel_enabled:
        print(f"   Max parallel agents: {max_parallel}")
    
    use_config = input("\nUse this configuration? [Y/n]: ").strip().lower()
    return not use_config or use_config == 'y'


def monitor_progress(coordinator: SwarmCoordinator):
    """Display progress during workflow execution"""
    # This is called after workflow completes
    # In a real implementation, you'd want to hook into the workflow execution
    # for real-time updates
    pass


def save_outputs(coordinator: SwarmCoordinator):
    """Save outputs to files"""
    print("\n💾 Saving outputs...")
    
    # Outputs are already saved in project directory by coordinator
    project_dir = coordinator.state.get("project_info", {}).get("project_dir")
    
    if project_dir:
        print(f"   ✓ All files saved to project directory:")
        print(f"      {project_dir}")
        
        # List what was saved
        if os.path.exists(os.path.join(project_dir, "src")):
            src_files = os.listdir(os.path.join(project_dir, "src"))
            if src_files:
                print(f"   ✓ Source code: {', '.join(src_files)}")
        
        if os.path.exists(os.path.join(project_dir, "tests")):
            test_files = os.listdir(os.path.join(project_dir, "tests"))
            if test_files:
                print(f"   ✓ Tests: {', '.join(test_files)}")
        
        if os.path.exists(os.path.join(project_dir, "docs")):
            doc_files = os.listdir(os.path.join(project_dir, "docs"))
            if doc_files:
                print(f"   ✓ Documentation: {', '.join(doc_files)}")
    else:
        print("   ⚠ No project directory found")
        
        # Fallback to old behavior
        code_task = next((t for t in coordinator.completed_tasks 
                         if t.task_type == "coding"), None)
        if code_task and code_task.result:
            with open("generated_code.txt", 'w') as f:
                f.write(code_task.result)
            print("   ✓ Code saved to: generated_code.txt")


def main():
    """Main entry point"""
    try:
        print_banner()
        
        # Check configuration
        if not check_configuration():
            print("\n❌ Configuration rejected. Exiting.")
            return
        
        # Create coordinator
        print("\n🚀 Initializing swarm coordinator...")
        coordinator = SwarmCoordinator(config_file="config_v2.json")
        print("✓ Coordinator ready")
        
        # Select workflow
        workflow_type = select_workflow()
        
        if workflow_type == 'custom':
            configure_custom_workflow(coordinator)
            user_request = get_multiline_input("\nEnter the overall project description:")
            
            # Store request in coordinator context
            coordinator.state["context"]["user_request"] = user_request
            
            # Execute custom workflow
            print("\n" + "=" * 80)
            print("EXECUTING CUSTOM WORKFLOW")
            print("=" * 80)
            
            # Run the workflow without creating default tasks
            coordinator.run_workflow("", workflow_type="custom")
            
        elif workflow_type == 'review_only':
            # Get code to review
            code = get_multiline_input("\nEnter the code to review:")
            
            if not code.strip():
                print("\n❌ No code provided. Exiting.")
                return
            
            # Create review workflow
            coordinator._create_review_workflow(code)
            
            print("\n" + "=" * 80)
            print("EXECUTING REVIEW WORKFLOW")
            print("=" * 80)
            
            # Execute workflow
            coordinator.run_workflow(code, workflow_type="review_only")
            
        else:
            # Standard or full workflow
            user_request = get_multiline_input(
                f"\n{'='*80}\nWhat would you like to build?\n{'='*80}\n"
            )
            
            if not user_request.strip():
                print("\n❌ No request provided. Exiting.")
                return
            
            print("\n" + "=" * 80)
            print(f"EXECUTING {workflow_type.upper()} WORKFLOW")
            print("=" * 80)
            
            coordinator.run_workflow(user_request, workflow_type=workflow_type)
        
        # Save outputs
        save_outputs(coordinator)
        
        # Display metrics summary
        print("\n" + "=" * 80)
        print("METRICS SUMMARY")
        print("=" * 80)
        metrics = coordinator.get_metrics_summary()
        print(json.dumps(metrics, indent=2))
        
        print("\n✓ Workflow complete!")
        
    except KeyboardInterrupt:
        print("\n\n⚠ Workflow interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
