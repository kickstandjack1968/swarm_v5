#!/usr/bin/env python3
"""
Advanced Multi-Agent Swarm Coordinator v2
- Parallel agent execution
- Dynamic routing and task distribution
- Enhanced state management
- Tool integration for agents
- Metrics and observability
"""

import json
import os
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from enum import Enum
import requests
from threading import Lock


class AgentRole(Enum):
    """Defined agent roles in the swarm"""
    ARCHITECT = "architect"          # System design, architecture decisions
    CLARIFIER = "clarifier"          # Requirements clarification
    CODER = "coder"                  # Code implementation
    REVIEWER = "reviewer"            # Code review
    TESTER = "tester"                # Test generation and validation
    OPTIMIZER = "optimizer"          # Performance optimization
    DOCUMENTER = "documenter"        # Documentation generation
    DEBUGGER = "debugger"            # Bug analysis and fixes
    SECURITY = "security"            # Security analysis
    

class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass
class AgentMetrics:
    """Metrics for agent performance tracking"""
    agent_name: str
    role: str
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    total_tokens: int = 0
    avg_response_time: float = 0.0
    last_call_time: Optional[float] = None
    
    def update(self, success: bool, response_time: float, tokens: int = 0):
        """Update metrics after an agent call"""
        self.total_calls += 1
        if success:
            self.successful_calls += 1
        else:
            self.failed_calls += 1
        
        self.total_tokens += tokens
        
        # Update average response time
        if self.avg_response_time == 0:
            self.avg_response_time = response_time
        else:
            self.avg_response_time = (self.avg_response_time * (self.total_calls - 1) + response_time) / self.total_calls
        
        self.last_call_time = response_time


@dataclass
class Task:
    """Represents a task in the workflow"""
    task_id: str
    task_type: str
    description: str
    assigned_role: AgentRole
    status: TaskStatus
    priority: int = 5  # 1-10, 10 is highest
    dependencies: List[str] = None
    result: Optional[str] = None
    error: Optional[str] = None
    created_at: float = None
    completed_at: Optional[float] = None
    metadata: Dict = None
    
    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []
        if self.created_at is None:
            self.created_at = time.time()
        if self.metadata is None:
            self.metadata = {}


class AgentExecutor:
    """Handles execution of individual agents"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.metrics = {}
        self.metrics_lock = Lock()
        
    def _get_agent_config(self, role: AgentRole) -> Dict:
        """Get configuration for specific agent role"""
        role_str = role.value
        mode = self.config['model_config']['mode']
        
        if mode == 'multi' and role_str in self.config['model_config']['multi_model']:
            return self.config['model_config']['multi_model'][role_str]
        elif mode == 'single':
            return self.config['model_config']['single_model']
        else:
            # Fallback mapping
            fallback_map = {
                AgentRole.ARCHITECT: 'clarifier',
                AgentRole.CLARIFIER: 'clarifier',
                AgentRole.CODER: 'coder',
                AgentRole.REVIEWER: 'reviewer',
                AgentRole.TESTER: 'reviewer',
                AgentRole.OPTIMIZER: 'coder',
                AgentRole.DOCUMENTER: 'clarifier',
                AgentRole.DEBUGGER: 'coder',
                AgentRole.SECURITY: 'reviewer'
            }
            fallback_role = fallback_map.get(role, 'coder')
            if fallback_role in self.config['model_config']['multi_model']:
                return self.config['model_config']['multi_model'][fallback_role]
        
        return self.config['model_config']['single_model']
    
    def _call_api(self, url: str, api_type: str, model: str, system_prompt: str, 
                  user_message: str, params: Dict, timeout: int) -> tuple[str, int]:
        """Make API call to LLM (returns response and approximate token count)"""
        start_time = time.time()
        
        try:
            if api_type == 'ollama':
                ollama_url = url.replace('/v1', '').rstrip('/')
                response = requests.post(
                    f"{ollama_url}/api/chat",
                    json={
                        "model": model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_message}
                        ],
                        "stream": False,
                        "options": {
                            "temperature": params.get('temperature', 0.7),
                            "num_predict": params.get('max_tokens', 4000),
                            "top_p": params.get('top_p', 0.9)
                        }
                    },
                    timeout=timeout
                )
                response.raise_for_status()
                result = response.json()
                content = result['message']['content']
                tokens = result.get('eval_count', 0) + result.get('prompt_eval_count', 0)
                return content, tokens
                
            else:  # OpenAI-compatible
                response = requests.post(
                    f"{url}/chat/completions",
                    json={
                        "model": model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_message}
                        ],
                        "temperature": params.get('temperature', 0.7),
                        "max_tokens": params.get('max_tokens', 4000),
                        "top_p": params.get('top_p', 0.9)
                    },
                    timeout=timeout
                )
                response.raise_for_status()
                result = response.json()
                content = result['choices'][0]['message']['content']
                tokens = result.get('usage', {}).get('total_tokens', 0)
                return content, tokens
                
        except Exception as e:
            raise Exception(f"API call failed: {str(e)}")
    
    def execute_agent(self, role: AgentRole, system_prompt: str, user_message: str, 
                      agent_params: Optional[Dict] = None) -> str:
        """Execute a single agent with the given prompts"""
        
        # Get agent configuration
        agent_config = self._get_agent_config(role)
        url = agent_config['url']
        model = agent_config.get('model', 'local-model')
        api_type = agent_config.get('api_type', 'openai')
        timeout = agent_config.get('timeout', 7200)
        
        # Merge parameters
        params = self.config.get('agent_parameters', {}).get(role.value, {})
        if agent_params:
            params.update(agent_params)
        
        # Initialize metrics if needed
        agent_key = f"{role.value}"
        if agent_key not in self.metrics:
            with self.metrics_lock:
                self.metrics[agent_key] = AgentMetrics(agent_name=agent_key, role=role.value)
        
        # Execute the call
        start_time = time.time()
        success = False
        tokens = 0
        
        try:
            response, tokens = self._call_api(url, api_type, model, system_prompt, 
                                             user_message, params, timeout)
            success = True
            return response
            
        except Exception as e:
            raise Exception(f"Agent {role.value} failed: {str(e)}")
            
        finally:
            elapsed = time.time() - start_time
            with self.metrics_lock:
                self.metrics[agent_key].update(success, elapsed, tokens)


class SwarmCoordinator:
    """Advanced coordinator for multi-agent swarm execution"""
    
    def __init__(self, config_file: str = "config.json"):
        self.config = self._load_config(config_file)
        self.executor = AgentExecutor(self.config)
        self.task_queue: List[Task] = []
        self.completed_tasks: List[Task] = []
        self.state = {
            "workflow_id": datetime.now().strftime("%Y%m%d_%H%M%S"),
            "phase": "initial",
            "iteration": 0,
            "max_iterations": self.config['workflow'].get('max_iterations', 3),
            "context": {},  # Shared context between agents
            "history": [],
            "project_info": {
                "project_number": None,
                "project_name": None,
                "version": 1,
                "project_dir": None
            }
        }
        self.max_parallel = self.config.get('workflow', {}).get('max_parallel_agents', 4)
        self.projects_root = "projects"
        self._ensure_projects_dir()
    
    def _load_config(self, config_file: str) -> Dict:
        """Load configuration from file"""
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        """Default configuration"""
        return {
            "model_config": {
                "mode": "single",
                "single_model": {
                    "url": "http://localhost:1234/v1",
                    "model": "local-model",
                    "api_type": "openai",
                    "timeout": 7200
                }
            },
            "agent_parameters": {
                "architect": {"temperature": 0.6, "max_tokens": 3000},
                "clarifier": {"temperature": 0.7, "max_tokens": 2000},
                "coder": {"temperature": 0.5, "max_tokens": 6000},
                "reviewer": {"temperature": 0.8, "max_tokens": 3000},
                "tester": {"temperature": 0.7, "max_tokens": 4000},
                "optimizer": {"temperature": 0.6, "max_tokens": 4000},
                "documenter": {"temperature": 0.7, "max_tokens": 3000},
                "debugger": {"temperature": 0.6, "max_tokens": 4000},
                "security": {"temperature": 0.8, "max_tokens": 3000}
            },
            "workflow": {
                "max_iterations": 3,
                "max_parallel_agents": 4,
                "enable_parallel": True
            }
        }
    
    def _ensure_projects_dir(self):
        """Ensure projects directory exists"""
        if not os.path.exists(self.projects_root):
            os.makedirs(self.projects_root)
    
    def _get_next_project_number(self) -> int:
        """Get next project number by scanning existing projects"""
        if not os.path.exists(self.projects_root):
            return 1
        
        existing = os.listdir(self.projects_root)
        numbers = []
        for dirname in existing:
            if dirname.startswith(('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')):
                try:
                    num = int(dirname.split('_')[0])
                    numbers.append(num)
                except (ValueError, IndexError):
                    continue
        
        return max(numbers) + 1 if numbers else 1
    
    def _create_project_name(self, user_request: str) -> str:
        """Generate project name from user request"""
        # Extract key words from request
        words = user_request.lower().split()
        
        # Filter out common words
        stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 
                     'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
                     'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
                     'should', 'could', 'may', 'might', 'must', 'can', 'create', 'make',
                     'build', 'write', 'generate', 'i', 'need', 'want', 'please', 'help'}
        
        keywords = [w for w in words[:10] if w not in stop_words and len(w) > 2]
        
        # Take first 3 meaningful words
        name_parts = keywords[:3] if keywords else ['project']
        
        # Clean and join
        project_name = '_'.join(name_parts[:3])
        
        # Remove non-alphanumeric
        project_name = ''.join(c if c.isalnum() or c == '_' else '_' for c in project_name)
        
        return project_name
    
    def _check_existing_project(self, project_name: str) -> Optional[int]:
        """Check if project exists and return latest version number"""
        if not os.path.exists(self.projects_root):
            return None
        
        # Look for projects with same base name
        existing = os.listdir(self.projects_root)
        versions = []
        
        for dirname in existing:
            # Format: NNN_projectname_vX
            if project_name in dirname and '_v' in dirname:
                try:
                    version = int(dirname.split('_v')[1])
                    versions.append(version)
                except (ValueError, IndexError):
                    continue
        
        return max(versions) if versions else None
    
    def _setup_project_directory(self, project_name: str, user_request: str):
        """Create project directory structure"""
        project_num = self._get_next_project_number()
        version = 1
        
        # Check if project exists
        existing_version = self._check_existing_project(project_name)
        if existing_version is not None:
            version = existing_version + 1
        
        # Create directory name: NNN_projectname_vX
        dir_name = f"{project_num:03d}_{project_name}_v{version}"
        project_dir = os.path.join(self.projects_root, dir_name)
        
        # Create structure
        os.makedirs(project_dir, exist_ok=True)
        os.makedirs(os.path.join(project_dir, "src"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "tests"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "docs"), exist_ok=True)
        
        # Store project info
        self.state["project_info"] = {
            "project_number": project_num,
            "project_name": project_name,
            "version": version,
            "project_dir": project_dir
        }
        
        # Create project info file
        self._create_project_info(user_request)
        
        return project_dir
    
    def _create_project_info(self, user_request: str):
        """Create PROJECT_INFO.txt in project directory"""
        project_dir = self.state["project_info"]["project_dir"]
        project_num = self.state["project_info"]["project_number"]
        version = self.state["project_info"]["version"]
        project_name = self.state["project_info"]["project_name"]
        
        info_content = f"""PROJECT INFORMATION
{'=' * 80}

Project Number: {project_num:03d}
Project Name: {project_name}
Version: {version}
Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Workflow ID: {self.state['workflow_id']}

{'=' * 80}
ORIGINAL REQUEST
{'=' * 80}

{user_request}

{'=' * 80}
PROJECT STRUCTURE
{'=' * 80}

{os.path.basename(project_dir)}/
├── src/              - Source code
├── tests/            - Test files
├── docs/             - Documentation
├── PROJECT_INFO.txt  - This file
└── requirements.txt  - Dependencies (if applicable)

{'=' * 80}
"""
        
        info_path = os.path.join(project_dir, "PROJECT_INFO.txt")
        with open(info_path, 'w') as f:
            f.write(info_content)
    
    def _save_project_outputs(self):
        """Save all outputs to project directory"""
        project_dir = self.state["project_info"]["project_dir"]
        if not project_dir:
            return
        
        # Save code
        code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
        if code_task and code_task.result:
            # Determine filename from project name
            project_name = self.state["project_info"]["project_name"]
            code_file = os.path.join(project_dir, "src", f"{project_name}.py")
            
            with open(code_file, 'w') as f:
                f.write(code_task.result)
        
        # Save tests
        test_task = next((t for t in self.completed_tasks if t.task_type == "test_generation"), None)
        if test_task and test_task.result:
            project_name = self.state["project_info"]["project_name"]
            test_file = os.path.join(project_dir, "tests", f"test_{project_name}.py")
            
            with open(test_file, 'w') as f:
                f.write(test_task.result)
        
        # Save documentation
        doc_task = next((t for t in self.completed_tasks if t.task_type == "documentation"), None)
        if doc_task and doc_task.result:
            doc_file = os.path.join(project_dir, "docs", "README.md")
            
            with open(doc_file, 'w') as f:
                f.write(doc_task.result)
        
        # Save review results
        review_tasks = [t for t in self.completed_tasks if "review" in t.task_type]
        if review_tasks:
            review_file = os.path.join(project_dir, "REVIEW_RESULTS.txt")
            
            with open(review_file, 'w') as f:
                f.write("CODE REVIEW RESULTS\n")
                f.write("=" * 80 + "\n\n")
                for i, task in enumerate(review_tasks, 1):
                    f.write(f"Review #{i} ({task.assigned_role.value}):\n")
                    f.write("-" * 80 + "\n")
                    f.write(task.result + "\n\n")
        
        # Save requirements.txt if optimizer ran
        optimizer_task = next((t for t in self.completed_tasks if t.task_type == "optimization"), None)
        if optimizer_task:
            # Extract dependencies from code
            self._create_requirements_txt(project_dir)
        
        # Save session state
        state_file = os.path.join(project_dir, "session_state.json")
        with open(state_file, 'w') as f:
            json.dump(self.state, f, indent=2, default=str)
    
    def add_task(self, task: Task):
        """Add a task to the queue"""
        self.task_queue.append(task)
        self.state["history"].append({
            "action": "task_added",
            "task_id": task.task_id,
            "task_type": task.task_type,
            "role": task.assigned_role.value,
            "timestamp": time.time()
        })
    
    def get_ready_tasks(self) -> List[Task]:
        """Get tasks that are ready to execute (dependencies met)"""
        ready = []
        completed_ids = {t.task_id for t in self.completed_tasks}
        
        for task in self.task_queue:
            if task.status == TaskStatus.PENDING:
                # Check if all dependencies are completed
                if all(dep_id in completed_ids for dep_id in task.dependencies):
                    ready.append(task)
        
        # Sort by priority (highest first)
        ready.sort(key=lambda t: t.priority, reverse=True)
        return ready
    
    def execute_task(self, task: Task) -> Task:
        """Execute a single task"""
        task.status = TaskStatus.IN_PROGRESS
        
        try:
            # Get the system prompt for this task type
            system_prompt = self._get_system_prompt(task.assigned_role, task.task_type)
            
            # Build user message with context
            user_message = self._build_user_message(task)
            
            # Execute the agent
            result = self.executor.execute_agent(
                role=task.assigned_role,
                system_prompt=system_prompt,
                user_message=user_message
            )
            
            task.result = result
            task.status = TaskStatus.COMPLETED
            task.completed_at = time.time()
            
            # Update shared context
            self._update_context(task)
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.completed_at = time.time()
        
        return task
    
    def execute_tasks_parallel(self, tasks: List[Task]) -> List[Task]:
        """Execute multiple tasks in parallel"""
        if not self.config.get('workflow', {}).get('enable_parallel', True):
            # Fall back to sequential execution
            return [self.execute_task(task) for task in tasks]
        
        completed = []
        with ThreadPoolExecutor(max_workers=min(len(tasks), self.max_parallel)) as executor:
            future_to_task = {executor.submit(self.execute_task, task): task for task in tasks}
            
            for future in as_completed(future_to_task):
                task = future_to_task[future]
                try:
                    completed_task = future.result()
                    completed.append(completed_task)
                except Exception as e:
                    task.status = TaskStatus.FAILED
                    task.error = str(e)
                    completed.append(task)
        
        return completed
    
    def _create_requirements_txt(self, project_dir: str):
        """Generate requirements.txt from code"""
        code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
        if not code_task or not code_task.result:
            return
        
        # Simple dependency extraction
        code = code_task.result
        imports = set()
        
        for line in code.split('\n'):
            line = line.strip()
            if line.startswith('import ') or line.startswith('from '):
                # Extract module name
                if line.startswith('import '):
                    module = line.replace('import ', '').split()[0].split('.')[0]
                else:
                    module = line.replace('from ', '').split()[0].split('.')[0]
                
                # Skip standard library
                stdlib = {'os', 'sys', 'json', 'time', 'datetime', 'collections', 're', 
                         'math', 'random', 'itertools', 'functools', 'pathlib', 'typing',
                         'logging', 'argparse', 'threading', 'multiprocessing'}
                
                if module not in stdlib:
                    imports.add(module)
        
        if imports:
            req_file = os.path.join(project_dir, "requirements.txt")
            with open(req_file, 'w') as f:
                for imp in sorted(imports):
                    f.write(f"{imp}\n")
    
    def run_workflow(self, user_request: str, workflow_type: str = "standard"):
        """Execute a complete workflow"""
        print("=" * 80)
        print(f"ADVANCED SWARM COORDINATOR v2")
        print(f"Workflow: {workflow_type}")
        print("=" * 80)
        
        # Setup project directory
        project_name = self._create_project_name(user_request)
        project_dir = self._setup_project_directory(project_name, user_request)
        
        print(f"\n📁 Project: {os.path.basename(project_dir)}")
        print(f"   Location: {project_dir}")
        print(f"   Number: {self.state['project_info']['project_number']:03d}")
        print(f"   Version: {self.state['project_info']['version']}")
        
        # Create initial tasks based on workflow type
        if workflow_type == "standard":
            self._create_standard_workflow(user_request)
        elif workflow_type == "full":
            self._create_full_workflow(user_request)
        elif workflow_type == "review_only":
            self._create_review_workflow(user_request)
        else:
            raise ValueError(f"Unknown workflow type: {workflow_type}")
        
        # Execute tasks
        while self.task_queue:
            ready_tasks = self.get_ready_tasks()
            
            if not ready_tasks:
                # Check if we have blocked tasks
                pending_tasks = [t for t in self.task_queue if t.status == TaskStatus.PENDING]
                if pending_tasks:
                    print(f"⚠ {len(pending_tasks)} tasks blocked waiting for dependencies")
                break
            
            print(f"\n▶ Executing {len(ready_tasks)} tasks (parallel: {self.config['workflow'].get('enable_parallel', True)})")
            
            # Execute ready tasks (in parallel if enabled)
            completed = self.execute_tasks_parallel(ready_tasks)
            
            # Move completed tasks to completed list
            for task in completed:
                if task in self.task_queue:
                    self.task_queue.remove(task)
                self.completed_tasks.append(task)
                
                status_symbol = "✓" if task.status == TaskStatus.COMPLETED else "✗"
                print(f"  {status_symbol} {task.task_id} ({task.assigned_role.value}): {task.status.value}")
        
        # Generate final report
        self._generate_workflow_report()
        
        # Save all outputs to project directory
        self._save_project_outputs()
        
        # Print project summary
        self._print_project_summary()
    
    def _print_project_summary(self):
        """Print summary of project outputs"""
        project_dir = self.state["project_info"]["project_dir"]
        project_name = os.path.basename(project_dir)
        
        print("\n" + "=" * 80)
        print("PROJECT OUTPUTS")
        print("=" * 80)
        print(f"\n📦 {project_name}/")
        
        # List generated files
        for root, dirs, files in os.walk(project_dir):
            level = root.replace(project_dir, '').count(os.sep)
            indent = '  ' * level
            rel_path = os.path.basename(root)
            if level > 0:
                print(f"{indent}├── {rel_path}/")
            
            sub_indent = '  ' * (level + 1)
            for file in files:
                print(f"{sub_indent}├── {file}")
        
        print(f"\n✓ All outputs saved to: {project_dir}")
        print(f"✓ Project number: {self.state['project_info']['project_number']:03d}")
        print(f"✓ Version: {self.state['project_info']['version']}")
    
    def _create_standard_workflow(self, user_request: str):
        """Create standard coding workflow: clarify -> code -> review"""
        
        # Task 1: Clarification
        self.add_task(Task(
            task_id="T001_clarify",
            task_type="clarification",
            description="Clarify requirements",
            assigned_role=AgentRole.CLARIFIER,
            status=TaskStatus.PENDING,
            priority=10,
            metadata={"user_request": user_request}
        ))
        
        # Task 2: Architecture (depends on clarification)
        self.add_task(Task(
            task_id="T002_architect",
            task_type="architecture",
            description="Design system architecture",
            assigned_role=AgentRole.ARCHITECT,
            status=TaskStatus.PENDING,
            priority=9,
            dependencies=["T001_clarify"]
        ))
        
        # Task 3: Coding (depends on architecture)
        self.add_task(Task(
            task_id="T003_code",
            task_type="coding",
            description="Implement the code",
            assigned_role=AgentRole.CODER,
            status=TaskStatus.PENDING,
            priority=8,
            dependencies=["T002_architect"]
        ))
        
        # Task 4-6: Multiple reviewers in parallel
        for i in range(1, 4):
            self.add_task(Task(
                task_id=f"T00{3+i}_review{i}",
                task_type="review",
                description=f"Code review #{i}",
                assigned_role=AgentRole.REVIEWER,
                status=TaskStatus.PENDING,
                priority=7,
                dependencies=["T003_code"],
                metadata={"reviewer_number": i}
            ))
    
    def _create_full_workflow(self, user_request: str):
        """Create comprehensive workflow with all agent types"""
        
        # Phase 1: Planning
        self.add_task(Task(
            task_id="T001_clarify",
            task_type="clarification",
            description="Clarify requirements",
            assigned_role=AgentRole.CLARIFIER,
            status=TaskStatus.PENDING,
            priority=10,
            metadata={"user_request": user_request}
        ))
        
        self.add_task(Task(
            task_id="T002_architect",
            task_type="architecture",
            description="Design architecture",
            assigned_role=AgentRole.ARCHITECT,
            status=TaskStatus.PENDING,
            priority=9,
            dependencies=["T001_clarify"]
        ))
        
        # Phase 2: Implementation
        self.add_task(Task(
            task_id="T003_code",
            task_type="coding",
            description="Implement code",
            assigned_role=AgentRole.CODER,
            status=TaskStatus.PENDING,
            priority=8,
            dependencies=["T002_architect"]
        ))
        
        # Phase 3: Quality assurance (parallel)
        self.add_task(Task(
            task_id="T004_review",
            task_type="review",
            description="Code review",
            assigned_role=AgentRole.REVIEWER,
            status=TaskStatus.PENDING,
            priority=7,
            dependencies=["T003_code"]
        ))
        
        self.add_task(Task(
            task_id="T005_security",
            task_type="security_audit",
            description="Security analysis",
            assigned_role=AgentRole.SECURITY,
            status=TaskStatus.PENDING,
            priority=7,
            dependencies=["T003_code"]
        ))
        
        self.add_task(Task(
            task_id="T006_tests",
            task_type="test_generation",
            description="Generate tests",
            assigned_role=AgentRole.TESTER,
            status=TaskStatus.PENDING,
            priority=7,
            dependencies=["T003_code"]
        ))
        
        # Phase 4: Optimization & Documentation (parallel)
        self.add_task(Task(
            task_id="T007_optimize",
            task_type="optimization",
            description="Optimize code",
            assigned_role=AgentRole.OPTIMIZER,
            status=TaskStatus.PENDING,
            priority=6,
            dependencies=["T004_review", "T005_security"]
        ))
        
        self.add_task(Task(
            task_id="T008_document",
            task_type="documentation",
            description="Generate documentation",
            assigned_role=AgentRole.DOCUMENTER,
            status=TaskStatus.PENDING,
            priority=6,
            dependencies=["T003_code"]
        ))
    
    def _create_review_workflow(self, code: str):
        """Create workflow for reviewing existing code"""
        
        # Multiple parallel reviews
        for i, review_type in enumerate(["correctness", "security", "performance", "style"], 1):
            self.add_task(Task(
                task_id=f"T00{i}_review_{review_type}",
                task_type=f"review_{review_type}",
                description=f"Review: {review_type}",
                assigned_role=AgentRole.REVIEWER if review_type != "security" else AgentRole.SECURITY,
                status=TaskStatus.PENDING,
                priority=10,
                metadata={"code": code, "review_focus": review_type}
            ))
    
    def _get_system_prompt(self, role: AgentRole, task_type: str) -> str:
        """Get system prompt for agent role and task type"""
        
        prompts = {
            AgentRole.ARCHITECT: """You are an expert software architect. Your role is to:
- Analyze requirements and design high-level system architecture
- Make technology and framework recommendations
- Define component structure and interfaces
- Identify potential technical challenges
- Suggest design patterns and best practices

Provide clear, structured architecture documentation.""",

            AgentRole.CLARIFIER: """You are a requirements analyst. Your role is to:
- Analyze user requests for clarity and completeness
- Identify ambiguities or missing information
- Ask focused, relevant clarifying questions
- Organize requirements into clear specifications

Return STATUS: CLEAR if requirements are complete, or ask specific questions.""",

            AgentRole.CODER: """You are an expert programmer. Your role is to:
- Write clean, efficient, well-documented code
- Follow best practices and coding standards
- Include proper error handling
- Add helpful comments
- Provide usage examples

Focus on code quality and maintainability.""",

            AgentRole.REVIEWER: """You are a code reviewer. Your role is to:
- Review code for correctness, bugs, and edge cases
- Check code quality and adherence to best practices
- Verify error handling and edge cases
- Suggest improvements

Return STATUS: APPROVED or STATUS: NEEDS_REVISION with specific issues.""",

            AgentRole.TESTER: """You are a test engineer. Your role is to:
- Generate comprehensive test cases
- Include unit tests, integration tests, edge cases
- Test error conditions and boundary cases
- Provide test coverage analysis

Create thorough, executable test suites.""",

            AgentRole.OPTIMIZER: """You are a performance optimization expert. Your role is to:
- Analyze code for performance bottlenecks
- Suggest algorithmic improvements
- Optimize memory usage and speed
- Provide benchmarking recommendations

Focus on measurable performance improvements.""",

            AgentRole.DOCUMENTER: """You are a technical writer. Your role is to:
- Generate clear, comprehensive documentation
- Include API references, usage examples
- Document configuration and setup
- Write user-friendly guides

Create professional documentation.""",

            AgentRole.DEBUGGER: """You are a debugging specialist. Your role is to:
- Analyze bug reports and error messages
- Identify root causes of issues
- Suggest fixes and workarounds
- Prevent similar bugs in the future

Provide actionable debugging solutions.""",

            AgentRole.SECURITY: """You are a security analyst. Your role is to:
- Identify security vulnerabilities
- Check for common security issues (injection, XSS, etc.)
- Verify input validation and sanitization
- Suggest security best practices

Focus on concrete security improvements."""
        }
        
        return prompts.get(role, "You are a helpful AI assistant.")
    
    def _build_user_message(self, task: Task) -> str:
        """Build user message with context for the task"""
        
        message_parts = [f"TASK: {task.description}\n"]
        
        # Add user request if in metadata
        if "user_request" in task.metadata:
            message_parts.append(f"USER REQUEST:\n{task.metadata['user_request']}\n")
        
        # Add code if in metadata
        if "code" in task.metadata:
            message_parts.append(f"CODE TO ANALYZE:\n{task.metadata['code']}\n")
        
        # Add context from dependent tasks
        if task.dependencies:
            message_parts.append("\nCONTEXT FROM PREVIOUS TASKS:")
            for dep_id in task.dependencies:
                dep_task = next((t for t in self.completed_tasks if t.task_id == dep_id), None)
                if dep_task and dep_task.result:
                    message_parts.append(f"\n[{dep_task.task_id} - {dep_task.assigned_role.value}]")
                    # Truncate very long results
                    result = dep_task.result[:2000] + "..." if len(dep_task.result) > 2000 else dep_task.result
                    message_parts.append(result)
        
        # Add review focus if specified
        if "review_focus" in task.metadata:
            message_parts.append(f"\nFOCUS YOUR REVIEW ON: {task.metadata['review_focus']}")
        
        # Add reviewer number if specified
        if "reviewer_number" in task.metadata:
            message_parts.append(f"\nYou are reviewer #{task.metadata['reviewer_number']}")
        
        return "\n".join(message_parts)
    
    def _update_context(self, task: Task):
        """Update shared context with task results"""
        context_key = f"{task.task_type}_{task.assigned_role.value}"
        self.state["context"][context_key] = {
            "task_id": task.task_id,
            "result": task.result,
            "completed_at": task.completed_at
        }
    
    def _generate_workflow_report(self):
        """Generate and print workflow execution report"""
        print("\n" + "=" * 80)
        print("WORKFLOW EXECUTION REPORT")
        print("=" * 80)
        
        total_tasks = len(self.completed_tasks)
        successful = sum(1 for t in self.completed_tasks if t.status == TaskStatus.COMPLETED)
        failed = total_tasks - successful
        
        print(f"\n📊 Task Summary:")
        print(f"   Total tasks: {total_tasks}")
        print(f"   ✓ Successful: {successful}")
        print(f"   ✗ Failed: {failed}")
        
        if self.completed_tasks:
            total_time = max(t.completed_at for t in self.completed_tasks if t.completed_at) - \
                        min(t.created_at for t in self.completed_tasks)
            print(f"   ⏱ Total time: {total_time:.2f}s")
        
        # Agent metrics
        print(f"\n📈 Agent Performance:")
        for agent_name, metrics in self.executor.metrics.items():
            success_rate = (metrics.successful_calls / metrics.total_calls * 100) if metrics.total_calls > 0 else 0
            print(f"   {agent_name}:")
            print(f"      Calls: {metrics.total_calls} (✓ {metrics.successful_calls}, ✗ {metrics.failed_calls})")
            print(f"      Success rate: {success_rate:.1f}%")
            print(f"      Avg response time: {metrics.avg_response_time:.2f}s")
            print(f"      Total tokens: {metrics.total_tokens}")
        
        # Task details
        print(f"\n📋 Task Details:")
        for task in self.completed_tasks:
            status_symbol = "✓" if task.status == TaskStatus.COMPLETED else "✗"
            duration = (task.completed_at - task.created_at) if task.completed_at else 0
            print(f"   {status_symbol} {task.task_id}: {task.description}")
            print(f"      Role: {task.assigned_role.value} | Duration: {duration:.2f}s")
            if task.error:
                print(f"      Error: {task.error}")
        
        # Final outputs
        print(f"\n📄 Final Outputs:")
        
        # Find code output
        code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
        if code_task and code_task.result:
            print("\n[GENERATED CODE]")
            print("-" * 80)
            print(code_task.result)
        
        # Find reviews
        review_tasks = [t for t in self.completed_tasks if "review" in t.task_type]
        if review_tasks:
            print("\n[REVIEW SUMMARIES]")
            print("-" * 80)
            for review in review_tasks:
                print(f"\n{review.task_id} ({review.assigned_role.value}):")
                print(review.result[:500] + "..." if len(review.result) > 500 else review.result)
    
    def save_state(self, filename: Optional[str] = None):
        """Save workflow state to file"""
        if filename is None:
            # Save to project directory if it exists
            if self.state.get("project_info", {}).get("project_dir"):
                project_dir = self.state["project_info"]["project_dir"]
                filename = os.path.join(project_dir, "session_state.json")
            else:
                filename = f"swarm_state_{self.state['workflow_id']}.json"
        
        state_data = {
            "workflow_id": self.state["workflow_id"],
            "phase": self.state["phase"],
            "iteration": self.state["iteration"],
            "context": self.state["context"],
            "history": self.state["history"],
            "project_info": self.state.get("project_info", {}),
            "completed_tasks": [asdict(t) for t in self.completed_tasks],
            "metrics": {k: asdict(v) for k, v in self.executor.metrics.items()}
        }
        
        with open(filename, 'w') as f:
            json.dump(state_data, f, indent=2, default=str)
        
        # Also save to sessions directory for history
        sessions_dir = "sessions"
        if os.path.exists(sessions_dir):
            session_file = os.path.join(sessions_dir, f"swarm_state_{self.state['workflow_id']}.json")
            with open(session_file, 'w') as f:
                json.dump(state_data, f, indent=2, default=str)
    
    def get_metrics_summary(self) -> Dict:
        """Get summary of all metrics"""
        return {
            "agents": {k: asdict(v) for k, v in self.executor.metrics.items()},
            "tasks": {
                "total": len(self.completed_tasks),
                "completed": sum(1 for t in self.completed_tasks if t.status == TaskStatus.COMPLETED),
                "failed": sum(1 for t in self.completed_tasks if t.status == TaskStatus.FAILED)
            }
        }


def main():
    """Example usage"""
    coordinator = SwarmCoordinator()
    
    # Example: Standard workflow
    user_request = """
    Create a Python function that takes a list of numbers and returns:
    1. The median value
    2. The standard deviation
    3. Outliers (values > 2 std devs from mean)
    
    Include error handling for edge cases.
    """
    
    coordinator.run_workflow(user_request, workflow_type="standard")


if __name__ == "__main__":
    main()
