#!/usr/bin/env python3
"""
Example: Project iteration (versioning)
Shows how the swarm handles improvements/iterations of the same project
"""

import sys
sys.path.insert(0, 'src')

from swarm_coordinator_v2 import SwarmCoordinator

def main():
    print("=" * 80)
    print("EXAMPLE: Project Iteration (Versioning)")
    print("=" * 80)
    
    coordinator = SwarmCoordinator(config_file="config/config_v2.json")
    
    # First version
    print("\n[CREATING VERSION 1]")
    request_v1 = """
    Create a simple CSV parser that:
    - Reads CSV files
    - Returns data as list of dictionaries
    - Handles basic errors
    """
    
    print(f"Request v1: {request_v1}")
    coordinator.run_workflow(request_v1, workflow_type="standard")
    
    v1_dir = coordinator.state["project_info"]["project_dir"]
    print(f"\n✓ Version 1 created: {v1_dir}")
    
    # Second version - improvements
    print("\n" + "=" * 80)
    print("[CREATING VERSION 2 - WITH IMPROVEMENTS]")
    coordinator2 = SwarmCoordinator(config_file="config/config_v2.json")
    
    request_v2 = """
    Create a CSV parser that:
    - Reads CSV files
    - Returns data as list of dictionaries
    - Handles encoding errors (UTF-8, Latin-1)
    - Validates column headers
    - Supports custom delimiters
    - Has comprehensive error messages
    - Includes type hints
    """
    
    print(f"Request v2: {request_v2}")
    coordinator2.run_workflow(request_v2, workflow_type="standard")
    
    v2_dir = coordinator2.state["project_info"]["project_dir"]
    print(f"\n✓ Version 2 created: {v2_dir}")
    
    # Show structure
    print("\n" + "=" * 80)
    print("PROJECT VERSIONING STRUCTURE")
    print("=" * 80)
    print("\nprojects/")
    print(f"├── {v1_dir.split('/')[-1]}/")
    print("│   └── [original implementation]")
    print(f"└── {v2_dir.split('/')[-1]}/")
    print("    └── [improved implementation]")
    
    print("\nNote: Same base name 'csv_parser' but different versions!")
    print("You can compare, rollback, or continue iterating.")


if __name__ == "__main__":
    main()
