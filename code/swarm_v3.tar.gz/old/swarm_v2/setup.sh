#!/bin/bash
# Setup script for Swarm Coordinator v2
# Run this on your air-gapped system

set -e

echo "╔══════════════════════════════════════════════════════════════════════════════╗"
echo "║                                                                              ║"
echo "║                  SWARM COORDINATOR v2 - INSTALLATION                         ║"
echo "║                                                                              ║"
echo "╚══════════════════════════════════════════════════════════════════════════════╝"
echo ""

# Check Python version
echo "Checking Python version..."
python3 --version || {
    echo "❌ Python 3 not found. Please install Python 3.7+"
    exit 1
}

echo "✓ Python 3 found"
echo ""

# Check for requests library
echo "Checking dependencies..."
python3 -c "import requests" 2>/dev/null && {
    echo "✓ requests library already installed"
} || {
    echo "Installing requests library..."
    pip3 install requests --break-system-packages || {
        echo "⚠ Warning: Could not install requests automatically"
        echo "Please install manually: pip3 install requests --break-system-packages"
    }
}
echo ""

# Make scripts executable
echo "Setting permissions..."
chmod +x *.py
echo "✓ Scripts are now executable"
echo ""

# Check for config file
if [ -f "config.json" ]; then
    echo "⚠ Found existing config.json"
    read -p "Back it up to config_backup.json? [Y/n] " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        cp config.json config_backup.json
        echo "✓ Backed up to config_backup.json"
    fi
fi

if [ ! -f "config.json" ]; then
    echo "Creating default config.json from config_v2.json..."
    cp config_v2.json config.json
    echo "✓ Created config.json"
    echo ""
    echo "⚠ IMPORTANT: Edit config.json to match your setup:"
    echo "   1. Update model URLs (LM Studio: port 1234, Ollama: port 11434)"
    echo "   2. Set correct model names for each agent"
    echo "   3. Adjust max_parallel_agents for your hardware"
fi
echo ""

# Create output directories
echo "Creating output directories..."
mkdir -p sessions logs metrics
echo "✓ Created: sessions/, logs/, metrics/"
echo ""

# Run validation
echo "═══════════════════════════════════════════════════════════════════════════════"
echo "Running system validation..."
echo "═══════════════════════════════════════════════════════════════════════════════"
echo ""

python3 quickstart.py || {
    echo ""
    echo "⚠ Validation had issues. Please review the output above."
    echo ""
}

echo ""
echo "═══════════════════════════════════════════════════════════════════════════════"
echo "INSTALLATION COMPLETE"
echo "═══════════════════════════════════════════════════════════════════════════════"
echo ""
echo "Next steps:"
echo "  1. Edit config.json to match your LM Studio/Ollama setup"
echo "  2. Ensure your model servers are running:"
echo "     • LM Studio: http://localhost:1234"
echo "     • Ollama: http://localhost:11434"
echo "  3. Run: ./quickstart.py (to validate setup)"
echo "  4. Run: ./interactive_v2.py (to start using the swarm)"
echo ""
echo "Documentation:"
echo "  • README.md - Complete usage guide"
echo "  • MIGRATION.md - Upgrade from v1"
echo "  • UPGRADE_SUMMARY.md - Quick overview of improvements"
echo ""
echo "Management tools:"
echo "  • ./swarm_manager.py - Analyze sessions, export metrics"
echo ""
echo "═══════════════════════════════════════════════════════════════════════════════"
