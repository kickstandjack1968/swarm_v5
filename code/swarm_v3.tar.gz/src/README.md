# Swarm UI - Web Interface Version

This is a **separate** swarm coordinator designed for web UI integration. It does **not** modify or replace your existing `swarm_coordinator_v2.py`.

## Key Differences from Terminal Version

| Feature | Terminal (v2) | UI Version |
|---------|---------------|------------|
| User input | `input()` | Callbacks/SSE |
| Progress | Print to stdout | Streaming updates |
| Clarification | Terminal prompt | UI modal |
| Blocking | Yes | No (async support) |

## Files

```
swarm_ui/
├── __init__.py                 # Module exports
├── swarm_coordinator_ui.py     # Main coordinator (no input())
└── service.py                  # Flask service layer
```

## Installation

Copy the `swarm_ui/` folder to your project's `src/` directory:

```bash
cp -r swarm_ui /path/to/your/project/src/
```

## Usage

### Direct Usage (Testing)

```python
from swarm_ui import SwarmCoordinatorUI, ProgressUpdate

# Create coordinator
coordinator = SwarmCoordinatorUI()

# Set up progress callback
def on_progress(update: ProgressUpdate):
    print(f"[{update.update_type}] {update.agent}: {update.message}")

coordinator.set_progress_callback(on_progress)

# Run workflow (yields progress updates)
for update in coordinator.run_workflow(
    user_request="Create a Python calculator",
    workflow_type="standard"
):
    print(update.to_dict())
```

### With Flask (Service Layer)

```python
from swarm_ui.service import get_swarm_ui_service

service = get_swarm_ui_service()

# Create task
task = service.create_task(
    description="Convert Excel to SQLite database",
    workflow_type="data",
    files=["/path/to/data.xlsx"]
)

# Execute with streaming (for SSE)
@app.route('/api/swarm/execute/<task_id>')
def execute(task_id):
    def generate():
        for update in service.execute_task(task_id):
            yield f"data: {json.dumps(update)}\n\n"
        yield "data: [DONE]\n\n"
    
    return Response(generate(), mimetype='text/event-stream')
```

### Handling Clarification Questions

When the clarifier has questions, the workflow pauses:

```python
# Task status becomes 'waiting_input'
# task.pending_question contains the questions

# When user provides answers:
for update in service.provide_answer(task_id, user_answer):
    yield f"data: {json.dumps(update)}\n\n"
```

## Workflow Types

| Type | Agents | Use Case |
|------|--------|----------|
| `standard` | clarifier → architect → coder → reviewer → documenter | General coding |
| `data` | clarifier → data_analyst → architect → coder → reviewer → documenter | Excel/DB tasks |
| `quick` | architect → coder → documenter | Simple tasks (no clarification) |

## Progress Update Types

| Type | When |
|------|------|
| `status` | General status messages |
| `agent_start` | Agent begins work |
| `agent_complete` | Agent finishes |
| `agent_error` | Agent failed |
| `question` | Clarifier needs input |
| `waiting` | Paused for user input |
| `task_complete` | Individual task done |
| `complete` | Workflow finished |
| `error` | Fatal error |

## Configuration

Uses same config format as v2. Place `config_v2.json` in project root or pass config dict:

```python
config = {
    "model_config": {
        "mode": "single",
        "single_model": {
            "url": "http://localhost:1234/v1",
            "model": "local-model",
            "api_type": "openai",
            "timeout": 7200
        }
    }
}

coordinator = SwarmCoordinatorUI(config=config)
```

## Your Terminal Swarm Stays Untouched

This module is completely separate. Your `swarm_coordinator_v2.py` continues to work exactly as before with all its interactive prompts.
