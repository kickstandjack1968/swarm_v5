"""
Swarm UI Module - Web interface version of the multi-agent swarm.

This module provides a SwarmCoordinator designed for web UI integration:
- No input() calls - uses callbacks
- Progress streaming
- Clarification through UI
- Non-blocking execution

Separate from swarm_coordinator_v2.py to avoid breaking terminal workflow.
"""

from .swarm_coordinator_ui import (
    SwarmCoordinatorUI,
    AgentRole,
    TaskStatus,
    SwarmState,
    Task,
    ProgressUpdate,
    create_swarm_ui
)

__all__ = [
    'SwarmCoordinatorUI',
    'AgentRole',
    'TaskStatus',
    'SwarmState',
    'Task',
    'ProgressUpdate',
    'create_swarm_ui'
]
