#!/usr/bin/env python3
"""
Advanced Multi-Agent Swarm Coordinator v2 - FIXED
- Parallel agent execution
- Dynamic routing and task distribution
- Enhanced state management
- Tool integration for agents
- Metrics and observability

FIXES APPLIED:
- Added VERIFIER to fallback map
- Fixed clarification flow to properly feed architect
- Added custom workflow support
- Fixed context propagation for all tasks
- Added revision loop when reviewer rejects
- Fixed security audit task handling
- Added proper empty result handling
- Fixed metrics lock issue
- Improved documenter to receive actual code
- Added user_request to all downstream contexts
"""

import json
import os
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict, field
from enum import Enum
import requests
from threading import Lock
import re


class AgentRole(Enum):
    """Defined agent roles in the swarm"""
    ARCHITECT = "architect"
    CLARIFIER = "clarifier"
    CODER = "coder"
    REVIEWER = "reviewer"
    TESTER = "tester"
    OPTIMIZER = "optimizer"
    DOCUMENTER = "documenter"
    DEBUGGER = "debugger"
    SECURITY = "security"
    VERIFIER = "verifier"


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    NEEDS_REVISION = "needs_revision"


@dataclass
class AgentMetrics:
    """Metrics for agent performance tracking"""
    agent_name: str
    role: str
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    total_tokens: int = 0
    avg_response_time: float = 0.0
    last_call_time: Optional[float] = None
    
    def update(self, success: bool, response_time: float, tokens: int = 0):
        """Update metrics after an agent call"""
        self.total_calls += 1
        if success:
            self.successful_calls += 1
        else:
            self.failed_calls += 1
        
        self.total_tokens += tokens
        
        # Update average response time
        if self.avg_response_time == 0:
            self.avg_response_time = response_time
        else:
            self.avg_response_time = (self.avg_response_time * (self.total_calls - 1) + response_time) / self.total_calls
        
        self.last_call_time = response_time


@dataclass
class Task:
    """Represents a task in the workflow"""
    task_id: str
    task_type: str
    description: str
    assigned_role: AgentRole
    status: TaskStatus
    priority: int = 5
    dependencies: List[str] = field(default_factory=list)
    result: Optional[str] = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    metadata: Dict = field(default_factory=dict)
    revision_count: int = 0
    max_revisions: int = 3


class AgentExecutor:
    """Handles execution of individual agents"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.metrics: Dict[str, AgentMetrics] = {}
        self.metrics_lock = Lock()
        
    def _get_agent_config(self, role: AgentRole) -> Dict:
        """Get configuration for specific agent role"""
        role_str = role.value
        mode = self.config['model_config']['mode']
        
        if mode == 'multi' and role_str in self.config['model_config']['multi_model']:
            return self.config['model_config']['multi_model'][role_str]
        elif mode == 'single':
            return self.config['model_config']['single_model']
        else:
            # FIXED: Added VERIFIER to fallback map
            fallback_map = {
                AgentRole.ARCHITECT: 'architect',
                AgentRole.CLARIFIER: 'clarifier',
                AgentRole.CODER: 'coder',
                AgentRole.REVIEWER: 'reviewer',
                AgentRole.TESTER: 'tester',
                AgentRole.OPTIMIZER: 'optimizer',
                AgentRole.DOCUMENTER: 'documenter',
                AgentRole.DEBUGGER: 'debugger',
                AgentRole.SECURITY: 'security',
                AgentRole.VERIFIER: 'verifier'
            }
            fallback_role = fallback_map.get(role, 'coder')
            if fallback_role in self.config['model_config']['multi_model']:
                return self.config['model_config']['multi_model'][fallback_role]
        
        return self.config['model_config']['single_model']
    
    def _call_api(self, url: str, api_type: str, model: str, system_prompt: str, 
                  user_message: str, params: Dict, timeout: int) -> tuple[str, int]:
        """Make API call to LLM (returns response and approximate token count)"""
        
        try:
            if api_type == 'ollama':
                ollama_url = url.replace('/v1', '').rstrip('/')
                response = requests.post(
                    f"{ollama_url}/api/chat",
                    json={
                        "model": model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_message}
                        ],
                        "stream": False,
                        "options": {
                            "temperature": params.get('temperature', 0.7),
                            "num_predict": params.get('max_tokens', 4000),
                            "top_p": params.get('top_p', 0.9)
                        }
                    },
                    timeout=timeout
                )
                response.raise_for_status()
                result = response.json()
                content = result.get('message', {}).get('content', '')
                tokens = result.get('eval_count', 0) + result.get('prompt_eval_count', 0)
                return content, tokens
                
            else:  # OpenAI-compatible
                response = requests.post(
                    f"{url}/chat/completions",
                    json={
                        "model": model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_message}
                        ],
                        "temperature": params.get('temperature', 0.7),
                        "max_tokens": params.get('max_tokens', 4000),
                        "top_p": params.get('top_p', 0.9)
                    },
                    timeout=timeout
                )
                response.raise_for_status()
                result = response.json()
                content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                tokens = result.get('usage', {}).get('total_tokens', 0)
                return content, tokens
                
        except requests.exceptions.Timeout:
            raise Exception(f"API call timed out after {timeout}s")
        except requests.exceptions.RequestException as e:
            raise Exception(f"API request failed: {str(e)}")
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            raise Exception(f"Invalid API response format: {str(e)}")
    
    def execute_agent(self, role: AgentRole, system_prompt: str, user_message: str, 
                      agent_params: Optional[Dict] = None) -> str:
        """Execute a single agent with the given prompts"""
        
        # Get agent configuration
        agent_config = self._get_agent_config(role)
        url = agent_config['url']
        model = agent_config.get('model', 'local-model')
        api_type = agent_config.get('api_type', 'openai')
        timeout = agent_config.get('timeout', 7200)
        
        # Merge parameters
        params = self.config.get('agent_parameters', {}).get(role.value, {}).copy()
        if agent_params:
            params.update(agent_params)
        
        # Initialize metrics if needed
        agent_key = role.value
        with self.metrics_lock:
            if agent_key not in self.metrics:
                self.metrics[agent_key] = AgentMetrics(agent_name=agent_key, role=role.value)
        
        # Execute the call
        start_time = time.time()
        success = False
        tokens = 0
        response = ""
        
        try:
            response, tokens = self._call_api(url, api_type, model, system_prompt, 
                                             user_message, params, timeout)
            # FIXED: Check for empty response
            if not response or not response.strip():
                raise Exception("Agent returned empty response")
            success = True
            return response
            
        except Exception as e:
            raise Exception(f"Agent {role.value} failed: {str(e)}")
            
        finally:
            elapsed = time.time() - start_time
            with self.metrics_lock:
                self.metrics[agent_key].update(success, elapsed, tokens)


class SwarmCoordinator:
    """Advanced coordinator for multi-agent swarm execution"""
    
    def __init__(self, config_file: str = "config_v2.json"):
        self.config = self._load_config(config_file)
        self.executor = AgentExecutor(self.config)
        self.task_queue: List[Task] = []
        self.completed_tasks: List[Task] = []
        self.state = {
            "workflow_id": datetime.now().strftime("%Y%m%d_%H%M%S"),
            "phase": "initial",
            "iteration": 0,
            "max_iterations": self.config.get('workflow', {}).get('max_iterations', 3),
            "context": {
                "user_request": "",  # FIXED: Initialize user_request in context
            },
            "history": [],
            "project_info": {
                "project_number": None,
                "project_name": None,
                "version": 1,
                "project_dir": None
            }
        }
        self.max_parallel = self.config.get('workflow', {}).get('max_parallel_agents', 4)
        self.projects_root = "projects"
        self._ensure_projects_dir()
    
    def _load_config(self, config_file: str) -> Dict:
        """Load configuration from file"""
        # Try multiple paths
        paths_to_try = [
            config_file,
            os.path.join("config", config_file),
            os.path.join(os.path.dirname(__file__), config_file),
            os.path.join(os.path.dirname(__file__), "config", config_file)
        ]
        
        for path in paths_to_try:
            if os.path.exists(path):
                try:
                    with open(path, 'r') as f:
                        return json.load(f)
                except json.JSONDecodeError as e:
                    print(f"Warning: Invalid JSON in {path}: {e}")
        
        print(f"Warning: Config file not found, using defaults")
        return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        """Default configuration"""
        return {
            "model_config": {
                "mode": "single",
                "single_model": {
                    "url": "http://localhost:1234/v1",
                    "model": "local-model",
                    "api_type": "openai",
                    "timeout": 7200
                }
            },
            "agent_parameters": {
                "architect": {"temperature": 0.6, "max_tokens": 3000},
                "clarifier": {"temperature": 0.7, "max_tokens": 2000},
                "coder": {"temperature": 0.5, "max_tokens": 6000},
                "reviewer": {"temperature": 0.8, "max_tokens": 3000},
                "tester": {"temperature": 0.7, "max_tokens": 4000},
                "optimizer": {"temperature": 0.6, "max_tokens": 4000},
                "documenter": {"temperature": 0.7, "max_tokens": 3000},
                "debugger": {"temperature": 0.6, "max_tokens": 4000},
                "security": {"temperature": 0.8, "max_tokens": 3000},
                "verifier": {"temperature": 0.3, "max_tokens": 3000}
            },
            "workflow": {
                "max_iterations": 3,
                "max_parallel_agents": 4,
                "enable_parallel": True
            }
        }
    
    def _ensure_projects_dir(self):
        """Ensure projects directory exists"""
        if not os.path.exists(self.projects_root):
            os.makedirs(self.projects_root)
    
    def _get_next_project_number(self) -> int:
        """Get next project number by scanning existing projects"""
        if not os.path.exists(self.projects_root):
            return 1
        
        existing = os.listdir(self.projects_root)
        numbers = []
        for dirname in existing:
            if dirname[0].isdigit():
                try:
                    num = int(dirname.split('_')[0])
                    numbers.append(num)
                except (ValueError, IndexError):
                    continue
        
        return max(numbers) + 1 if numbers else 1
    
    def _create_project_name(self, user_request: str) -> str:
        """Generate project name from user request"""
        words = user_request.lower().split()
        
        stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 
                     'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
                     'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
                     'should', 'could', 'may', 'might', 'must', 'can', 'create', 'make',
                     'build', 'write', 'generate', 'i', 'need', 'want', 'please', 'help',
                     'that', 'this', 'which', 'what', 'where', 'when', 'how', 'why'}
        
        keywords = [w for w in words[:15] if w not in stop_words and len(w) > 2]
        name_parts = keywords[:3] if keywords else ['project']
        project_name = '_'.join(name_parts)
        project_name = ''.join(c if c.isalnum() or c == '_' else '_' for c in project_name)
        project_name = re.sub(r'_+', '_', project_name).strip('_')
        
        return project_name or 'project'
    
    def _check_existing_project(self, project_name: str) -> Optional[int]:
        """Check if project exists and return latest version number"""
        if not os.path.exists(self.projects_root):
            return None
        
        existing = os.listdir(self.projects_root)
        versions = []
        
        for dirname in existing:
            if project_name in dirname and '_v' in dirname:
                try:
                    version = int(dirname.split('_v')[-1])
                    versions.append(version)
                except (ValueError, IndexError):
                    continue
        
        return max(versions) if versions else None
    
    def _setup_project_directory(self, project_name: str, user_request: str) -> str:
        """Create project directory structure"""
        project_num = self._get_next_project_number()
        version = 1
        
        existing_version = self._check_existing_project(project_name)
        if existing_version is not None:
            version = existing_version + 1
        
        dir_name = f"{project_num:03d}_{project_name}_v{version}"
        project_dir = os.path.join(self.projects_root, dir_name)
        
        os.makedirs(project_dir, exist_ok=True)
        os.makedirs(os.path.join(project_dir, "src"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "tests"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "docs"), exist_ok=True)
        
        self.state["project_info"] = {
            "project_number": project_num,
            "project_name": project_name,
            "version": version,
            "project_dir": project_dir
        }
        
        self._create_project_info(user_request)
        
        return project_dir
    
    def _create_project_info(self, user_request: str):
        """Create PROJECT_INFO.txt in project directory"""
        project_dir = self.state["project_info"]["project_dir"]
        project_num = self.state["project_info"]["project_number"]
        version = self.state["project_info"]["version"]
        project_name = self.state["project_info"]["project_name"]
        
        info_content = f"""PROJECT INFORMATION
{'=' * 80}

Project Number: {project_num:03d}
Project Name: {project_name}
Version: {version}
Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Workflow ID: {self.state['workflow_id']}

{'=' * 80}
ORIGINAL REQUEST
{'=' * 80}

{user_request}

{'=' * 80}
PROJECT STRUCTURE
{'=' * 80}

{os.path.basename(project_dir)}/
├── src/              - Source code
├── tests/            - Test files
├── docs/             - Documentation
├── PROJECT_INFO.txt  - This file
└── requirements.txt  - Dependencies (if applicable)

{'=' * 80}
"""
        
        info_path = os.path.join(project_dir, "PROJECT_INFO.txt")
        with open(info_path, 'w') as f:
            f.write(info_content)
    
    def _save_project_outputs(self):
        """Save all outputs to project directory"""
        project_dir = self.state["project_info"].get("project_dir")
        if not project_dir:
            return
        
        # Save code - handle multi-file output
        code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
        if code_task and code_task.result:
            files_dict = self._parse_multi_file_output(code_task.result)
            
            if files_dict:
                # Multi-file output detected
                for filename, content in files_dict.items():
                    code_file = os.path.join(project_dir, "src", filename)
                    os.makedirs(os.path.dirname(code_file), exist_ok=True)
                    with open(code_file, 'w') as f:
                        f.write(content)
                print(f"   ✓ Created {len(files_dict)} source files")
            else:
                # Single file output (legacy behavior)
                project_name = self.state["project_info"]["project_name"]
                code_file = os.path.join(project_dir, "src", f"{project_name}.py")
                
                with open(code_file, 'w') as f:
                    f.write(code_task.result)
        
        # Save tests
        test_task = next((t for t in self.completed_tasks if t.task_type == "test_generation"), None)
        if test_task and test_task.result:
            project_name = self.state["project_info"]["project_name"]
            test_file = os.path.join(project_dir, "tests", f"test_{project_name}.py")
            
            with open(test_file, 'w') as f:
                f.write(test_task.result)
        
        # Save documentation
        doc_task = next((t for t in self.completed_tasks if t.task_type == "documentation"), None)
        if doc_task and doc_task.result:
            doc_file = os.path.join(project_dir, "docs", "README.md")
            
            with open(doc_file, 'w') as f:
                f.write(doc_task.result)
            
            # Also copy to project root
            root_readme = os.path.join(project_dir, "README.md")
            with open(root_readme, 'w') as f:
                f.write(doc_task.result)
        
        # Save review results
        review_tasks = [t for t in self.completed_tasks if "review" in t.task_type and t.result]
        if review_tasks:
            review_file = os.path.join(project_dir, "REVIEW_RESULTS.txt")
            
            with open(review_file, 'w') as f:
                f.write("CODE REVIEW RESULTS\n")
                f.write("=" * 80 + "\n\n")
                for i, task in enumerate(review_tasks, 1):
                    f.write(f"Review #{i} ({task.assigned_role.value}):\n")
                    f.write("-" * 80 + "\n")
                    f.write(task.result + "\n\n")
        
        # Save requirements.txt
        self._create_requirements_txt(project_dir)
        
        # Save session state
        self.save_state()
    
    def _parse_multi_file_output(self, code_output: str) -> Dict[str, str]:
        """
        Parse coder output that contains multiple files.
        Returns dict of {filename: content} or empty dict if single-file output.
        
        Expected format:
        ### FILE: filename.py ###
        <code content>
        
        ### FILE: another.py ###
        <code content>
        """
        # Pattern to match file headers: ### FILE: name.py ###
        file_pattern = r'###\s*FILE:\s*([^\s#]+)\s*###'
        
        matches = list(re.finditer(file_pattern, code_output))
        
        if not matches:
            return {}  # Single file output
        
        files = {}
        for i, match in enumerate(matches):
            filename = match.group(1).strip()
            start_pos = match.end()
            
            # Find end position (start of next file or end of string)
            if i + 1 < len(matches):
                end_pos = matches[i + 1].start()
            else:
                end_pos = len(code_output)
            
            content = code_output[start_pos:end_pos].strip()
            
            # Clean any remaining markdown artifacts
            content = self._clean_file_content(content)
            
            if content:
                files[filename] = content
        
        return files
    
    def _clean_file_content(self, content: str) -> str:
        """Clean individual file content from markdown artifacts"""
        lines = content.split('\n')
        cleaned = []
        
        for line in lines:
            # Skip markdown code block markers
            if line.strip().startswith('```'):
                continue
            cleaned.append(line)
        
        return '\n'.join(cleaned).strip()
    
    def _verify_coder_files(self, architect_result: str, coder_result: str) -> tuple[bool, List[str]]:
        """
        Verify that coder created all files specified by architect.
        Returns (passed, list_of_missing_files)
        """
        # Extract expected files from architect output
        expected_files = self._extract_expected_files(architect_result)
        
        if not expected_files:
            return True, []  # No specific files required
        
        # Extract actual files from coder output
        actual_files = set(self._parse_multi_file_output(coder_result).keys())
        
        # If coder produced single file, try to infer from content
        if not actual_files:
            # Check if it's just a single-file project
            if len(expected_files) <= 1:
                return True, []
            # Multiple files expected but got single output
            return False, list(expected_files)
        
        # Compare
        missing = expected_files - actual_files
        
        if missing:
            return False, list(missing)
        
        return True, []
    
    def _extract_expected_files(self, architect_result: str) -> set:
        """Extract expected file names from architect's design"""
        files = set()
        
        # Common patterns architects use to specify files
        patterns = [
            r'(?:^|\n)\s*[-*]\s*`?(\w+\.py)`?',  # - file.py or * file.py
            r'(?:^|\n)\s*(\w+\.py)\s*[-:]',       # file.py - description
            r'File:\s*`?(\w+\.py)`?',              # File: name.py
            r'Module:\s*`?(\w+\.py)`?',            # Module: name.py
            r'(\w+\.py)\s*(?:module|file)',        # name.py module/file
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, architect_result, re.IGNORECASE)
            files.update(m.lower() for m in matches)
        
        # Also look for explicit file listings
        # Pattern: something.py (with description)
        file_list_pattern = r'\b(\w+\.py)\b'
        all_py_files = re.findall(file_list_pattern, architect_result)
        
        # Only include if they appear to be deliverables (mentioned multiple times or in specific contexts)
        file_counts = {}
        for f in all_py_files:
            f_lower = f.lower()
            file_counts[f_lower] = file_counts.get(f_lower, 0) + 1
        
        # Add files mentioned multiple times or in deliverables section
        deliverables_section = re.search(r'deliverables?[:\s]+(.*?)(?:\n\n|\Z)', 
                                         architect_result, re.IGNORECASE | re.DOTALL)
        if deliverables_section:
            section_files = re.findall(r'\b(\w+\.py)\b', deliverables_section.group(1))
            files.update(f.lower() for f in section_files)
        
        return files
        
        # Save requirements.txt
        self._create_requirements_txt(project_dir)
        
        # Save session state
        self.save_state()
    
    def _create_requirements_txt(self, project_dir: str):
        """Generate requirements.txt from code"""
        code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
        if not code_task or not code_task.result:
            return
        
        code = code_task.result
        imports = set()
        
        stdlib = {'os', 'sys', 'json', 'time', 'datetime', 'collections', 're', 
                 'math', 'random', 'itertools', 'functools', 'pathlib', 'typing',
                 'logging', 'argparse', 'threading', 'multiprocessing', 'copy',
                 'abc', 'dataclasses', 'enum', 'io', 'string', 'textwrap',
                 'unittest', 'csv', 'pickle', 'hashlib', 'base64', 'uuid',
                 'tempfile', 'shutil', 'glob', 'fnmatch', 'stat', 'contextlib',
                 'warnings', 'traceback', 'inspect', 'dis', 'gc', 'weakref',
                 'heapq', 'bisect', 'array', 'queue', 'struct', 'codecs',
                 'locale', 'gettext', 'numbers', 'decimal', 'fractions',
                 'cmath', 'statistics', 'operator', 'ast', 'types', 'pprint'}
        
        for line in code.split('\n'):
            line = line.strip()
            if line.startswith('import ') or line.startswith('from '):
                if line.startswith('import '):
                    module = line.replace('import ', '').split()[0].split('.')[0].split(',')[0]
                else:
                    module = line.replace('from ', '').split()[0].split('.')[0]
                
                if module and module not in stdlib:
                    imports.add(module)
        
        if imports:
            req_file = os.path.join(project_dir, "requirements.txt")
            with open(req_file, 'w') as f:
                for imp in sorted(imports):
                    f.write(f"{imp}\n")
    
    def add_task(self, task: Task):
        """Add a task to the queue"""
        self.task_queue.append(task)
        self.state["history"].append({
            "action": "task_added",
            "task_id": task.task_id,
            "task_type": task.task_type,
            "role": task.assigned_role.value,
            "timestamp": time.time()
        })
    
    def get_ready_tasks(self) -> List[Task]:
        """Get tasks that are ready to execute (dependencies met)"""
        ready = []
        completed_ids = {t.task_id for t in self.completed_tasks}
        
        for task in self.task_queue:
            if task.status == TaskStatus.PENDING:
                if all(dep_id in completed_ids for dep_id in task.dependencies):
                    ready.append(task)
        
        ready.sort(key=lambda t: t.priority, reverse=True)
        return ready
    
    def execute_task(self, task: Task) -> Task:
        """Execute a single task"""
        task.status = TaskStatus.IN_PROGRESS
        
        try:
            # Handle verification task specially
            if task.task_type == "verification":
                system_prompt, user_message = self._get_verifier_prompt(task)
                result = self.executor.execute_agent(AgentRole.VERIFIER, system_prompt, user_message)
                task.result = result
                
                if "FAIL" in result.upper() or "REJECT" in result.upper():
                    print("\n" + "=" * 80)
                    print("⚠️ VERIFICATION FAILED")
                    print("=" * 80)
                    print(result)
                    print("=" * 80)
                    task.status = TaskStatus.FAILED
                else:
                    print("\n✓ Verification passed - project ready for delivery")
                    task.status = TaskStatus.COMPLETED
                
                task.completed_at = time.time()
                return task
            
            # Regular task handling
            system_prompt = self._get_system_prompt(task.assigned_role, task.task_type)
            user_message = self._build_user_message(task)
            
            result = self.executor.execute_agent(
                role=task.assigned_role,
                system_prompt=system_prompt,
                user_message=user_message
            )
            
            # Clean code output if this is a coding task
            if task.task_type == "coding" and result:
                result = self._clean_code_output(result)
                
                # FILE VERIFICATION GATE: Check if coder produced expected files
                architect_task = next((t for t in self.completed_tasks 
                                       if t.assigned_role == AgentRole.ARCHITECT), None)
                if architect_task and architect_task.result:
                    passed, missing = self._verify_coder_files(architect_task.result, result)
                    if not passed and missing:
                        print(f"\n⚠️ FILE VERIFICATION WARNING: Missing files: {', '.join(missing)}")
                        # Store for potential retry
                        task.metadata["missing_files"] = missing
                        task.metadata["file_verification_failed"] = True
            
            task.result = result
            task.status = TaskStatus.COMPLETED
            task.completed_at = time.time()
            
            # Update shared context
            self._update_context(task)
            
            # FIXED: Check for reviewer rejection and trigger revision
            if task.task_type == "review" and result:
                if "NEEDS_REVISION" in result.upper() or "STATUS: REJECT" in result.upper():
                    task.metadata["needs_revision"] = True
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.completed_at = time.time()
            print(f"  ✗ Task {task.task_id} failed: {e}")
        
        return task
    
    def _clean_code_output(self, code: str) -> str:
        """Clean markdown formatting and explanatory text from code output"""
        
        # Check if this is multi-file output with our markers - if so, preserve structure
        if '### FILE:' in code:
            # Just clean markdown code blocks but preserve file structure
            lines = code.split('\n')
            cleaned = []
            for line in lines:
                # Skip markdown code block markers
                if line.strip().startswith('```'):
                    continue
                cleaned.append(line)
            return '\n'.join(cleaned).strip()
        
        # Single file output - apply normal cleaning
        # First, try to extract from markdown code blocks
        code_block_pattern = r'```(?:python)?\n(.*?)```'
        matches = re.findall(code_block_pattern, code, re.DOTALL)
        if matches:
            code = '\n\n'.join(matches)
        
        lines = code.split('\n')
        cleaned_lines = []
        found_code_start = False
        
        for line in lines:
            stripped = line.strip()
            
            # Skip empty lines before code starts
            if not found_code_start and not stripped:
                continue
            
            # Skip markdown headers (but not our file markers)
            if re.match(r'^#{1,6}\s', line) and '### FILE:' not in line:
                continue
            
            # Skip numbered lists at start
            if not found_code_start and re.match(r'^\d+\.\s', stripped):
                continue
            
            # Skip bold markdown headers
            if stripped.startswith('**') and stripped.endswith('**'):
                continue
            
            # Detect actual Python code or file markers
            code_indicators = (
                stripped.startswith('import '),
                stripped.startswith('from '),
                stripped.startswith('class '),
                stripped.startswith('def '),
                stripped.startswith('"""'),
                stripped.startswith("'''"),
                stripped.startswith('@'),  # decorators
                stripped.startswith('#!'),  # shebang
                (stripped.startswith('#') and not stripped.startswith('###')),
                '### FILE:' in stripped  # Our file markers
            )
            
            if any(code_indicators):
                found_code_start = True
            
            if found_code_start:
                cleaned_lines.append(line)
        
        return '\n'.join(cleaned_lines).strip()
    
    def execute_tasks_parallel(self, tasks: List[Task]) -> List[Task]:
        """Execute multiple tasks in parallel"""
        if not self.config.get('workflow', {}).get('enable_parallel', True) or len(tasks) <= 1:
            return [self.execute_task(task) for task in tasks]
        
        completed = []
        with ThreadPoolExecutor(max_workers=min(len(tasks), self.max_parallel)) as executor:
            future_to_task = {executor.submit(self.execute_task, task): task for task in tasks}
            
            for future in as_completed(future_to_task):
                task = future_to_task[future]
                try:
                    completed_task = future.result()
                    completed.append(completed_task)
                except Exception as e:
                    task.status = TaskStatus.FAILED
                    task.error = str(e)
                    task.completed_at = time.time()
                    completed.append(task)
        
        return completed
    
    def _handle_clarification_interactive(self, task: Task):
        """Handle clarification task by showing questions to user and getting answers"""
        if not task.result:
            return
        
        result = task.result.strip()
        
        # Check if requirements are already clear
        if "STATUS: CLEAR" in result.upper():
            print("\n✓ Requirements are clear, proceeding...")
            self.state["context"]['clarification'] = "Requirements are clear and complete."
            return
        
        # Extract and display questions
        print("\n" + "=" * 80)
        print("CLARIFICATION NEEDED")
        print("=" * 80)
        print("\nThe clarifier has identified some questions:\n")
        print(result)
        print("\n" + "=" * 80)
        
        # Get user input
        print("\nPlease provide answers to these questions:")
        print("(Enter your answers, then type 'DONE' on a new line when finished)\n")
        
        user_answers = []
        while True:
            try:
                line = input()
                if line.strip().upper() == 'DONE':
                    break
                user_answers.append(line)
            except EOFError:
                break
        
        answers_text = '\n'.join(user_answers)
        
        # FIXED: Store comprehensive clarified requirements
        user_request = self.state["context"].get("user_request", task.metadata.get('user_request', ''))
        clarified_req = f"ORIGINAL REQUEST:\n{user_request}\n\n"
        clarified_req += f"CLARIFICATION QUESTIONS:\n{result}\n\n"
        clarified_req += f"USER ANSWERS:\n{answers_text}"
        
        self.state["context"]['clarification'] = clarified_req
        self.state["context"]['user_answers'] = answers_text
        
        print("\n✓ Clarification complete, proceeding with workflow...")
    
    def _handle_revision_cycle(self, review_tasks: List[Task]) -> bool:
        """
        Check if any review requires revision and handle the cycle.
        Returns True if revision was triggered.
        """
        needs_revision = any(
            t.metadata.get("needs_revision", False) 
            for t in review_tasks 
            if t.status == TaskStatus.COMPLETED
        )
        
        if not needs_revision:
            return False
        
        # Find the coding task
        code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
        if not code_task:
            return False
        
        # Check revision count
        if code_task.revision_count >= code_task.max_revisions:
            print(f"\n⚠ Max revisions ({code_task.max_revisions}) reached, proceeding anyway")
            return False
        
        print(f"\n🔄 Revision cycle {code_task.revision_count + 1}/{code_task.max_revisions}")
        
        # Collect review feedback
        feedback = []
        for rt in review_tasks:
            if rt.result and rt.metadata.get("needs_revision"):
                feedback.append(f"[{rt.task_id}]: {rt.result}")
        
        # Create revision task
        revision_task = Task(
            task_id=f"T_revision_{code_task.revision_count + 1}",
            task_type="coding",
            description="Revise code based on review feedback",
            assigned_role=AgentRole.CODER,
            status=TaskStatus.PENDING,
            priority=10,
            metadata={
                "revision_feedback": "\n\n".join(feedback),
                "original_code": code_task.result,
                "user_request": self.state["context"].get("user_request", "")
            }
        )
        revision_task.revision_count = code_task.revision_count + 1
        
        # Execute revision
        self.execute_task(revision_task)
        
        if revision_task.status == TaskStatus.COMPLETED:
            # Update the context with revised code
            self._update_context(revision_task)
            self.completed_tasks.append(revision_task)
            return True
        
        return False
    
    def run_workflow(self, user_request: str, workflow_type: str = "standard"):
        """Execute a complete workflow"""
        print("=" * 80)
        print(f"ADVANCED SWARM COORDINATOR v2")
        print(f"Workflow: {workflow_type}")
        print("=" * 80)
        
        # FIXED: Store user request in context for all downstream tasks
        self.state["context"]["user_request"] = user_request
        
        # Setup project directory (skip for custom if already has tasks)
        if workflow_type != "custom" or not self.task_queue:
            project_name = self._create_project_name(user_request) if user_request else "custom_project"
            project_dir = self._setup_project_directory(project_name, user_request or "Custom workflow")
            
            print(f"\n📁 Project: {os.path.basename(project_dir)}")
            print(f"   Location: {project_dir}")
            print(f"   Number: {self.state['project_info']['project_number']:03d}")
            print(f"   Version: {self.state['project_info']['version']}")
        
        # Create initial tasks based on workflow type
        if workflow_type == "standard":
            self._create_standard_workflow(user_request)
        elif workflow_type == "full":
            self._create_full_workflow(user_request)
        elif workflow_type == "review_only":
            self._create_review_workflow(user_request)
        elif workflow_type == "custom":
            # FIXED: Custom workflow - tasks already added by caller
            if not self.task_queue:
                print("⚠ No tasks in custom workflow queue")
                return
        else:
            raise ValueError(f"Unknown workflow type: {workflow_type}")
        
        # Execute tasks
        iteration = 0
        max_iterations = self.state["max_iterations"]
        
        while self.task_queue and iteration < max_iterations * 10:  # Safety limit
            iteration += 1
            ready_tasks = self.get_ready_tasks()
            
            if not ready_tasks:
                pending_tasks = [t for t in self.task_queue if t.status == TaskStatus.PENDING]
                if pending_tasks:
                    print(f"⚠ {len(pending_tasks)} tasks blocked waiting for dependencies")
                break
            
            print(f"\n▶ Iteration {iteration}: Executing {len(ready_tasks)} tasks")
            
            completed = self.execute_tasks_parallel(ready_tasks)
            
            for task in completed:
                if task in self.task_queue:
                    self.task_queue.remove(task)
                self.completed_tasks.append(task)
                
                status_symbol = "✓" if task.status == TaskStatus.COMPLETED else "✗"
                print(f"  {status_symbol} {task.task_id} ({task.assigned_role.value}): {task.status.value}")
                
                # Handle clarification tasks
                if task.task_type == "clarification" and task.status == TaskStatus.COMPLETED:
                    self._handle_clarification_interactive(task)
            
            # FIXED: Check for revision cycle after reviews complete
            review_tasks = [t for t in completed if "review" in t.task_type]
            if review_tasks:
                self._handle_revision_cycle(review_tasks)
        
        # Generate final report
        self._generate_workflow_report()
        
        # Save all outputs
        self._save_project_outputs()
        
        # Print project summary
        self._print_project_summary()
    
    def _print_project_summary(self):
        """Print summary of project outputs"""
        project_dir = self.state["project_info"].get("project_dir")
        if not project_dir:
            return
            
        project_name = os.path.basename(project_dir)
        
        print("\n" + "=" * 80)
        print("PROJECT OUTPUTS")
        print("=" * 80)
        print(f"\n📦 {project_name}/")
        
        for root, dirs, files in os.walk(project_dir):
            level = root.replace(project_dir, '').count(os.sep)
            indent = '  ' * level
            rel_path = os.path.basename(root)
            if level > 0:
                print(f"{indent}├── {rel_path}/")
            
            sub_indent = '  ' * (level + 1)
            for file in files:
                print(f"{sub_indent}├── {file}")
        
        print(f"\n✓ All outputs saved to: {project_dir}")
        print(f"✓ Project number: {self.state['project_info']['project_number']:03d}")
        print(f"✓ Version: {self.state['project_info']['version']}")
    
    def _create_standard_workflow(self, user_request: str):
        """Create standard coding workflow: clarify -> architect -> code -> review -> document -> verify"""
        
        # Task 1: Clarification
        self.add_task(Task(
            task_id="T001_clarify",
            task_type="clarification",
            description="Clarify requirements",
            assigned_role=AgentRole.CLARIFIER,
            status=TaskStatus.PENDING,
            priority=10,
            metadata={"user_request": user_request}
        ))
        
        # Task 2: Architecture
        self.add_task(Task(
            task_id="T002_architect",
            task_type="architecture",
            description="Design system architecture",
            assigned_role=AgentRole.ARCHITECT,
            status=TaskStatus.PENDING,
            priority=9,
            dependencies=["T001_clarify"],
            metadata={"user_request": user_request}
        ))
        
        # Task 3: Coding
        self.add_task(Task(
            task_id="T003_code",
            task_type="coding",
            description="Implement the code",
            assigned_role=AgentRole.CODER,
            status=TaskStatus.PENDING,
            priority=8,
            dependencies=["T002_architect"],
            metadata={"user_request": user_request}
        ))
        
        # Tasks 4-6: Multiple reviewers in parallel
        for i in range(1, 4):
            self.add_task(Task(
                task_id=f"T00{3+i}_review{i}",
                task_type="review",
                description=f"Code review #{i}",
                assigned_role=AgentRole.REVIEWER,
                status=TaskStatus.PENDING,
                priority=7,
                dependencies=["T003_code"],
                metadata={"reviewer_number": i, "user_request": user_request}
            ))
        
        # Task 7: Documentation
        self.add_task(Task(
            task_id="T007_document",
            task_type="documentation",
            description="Generate documentation",
            assigned_role=AgentRole.DOCUMENTER,
            status=TaskStatus.PENDING,
            priority=6,
            dependencies=["T004_review1", "T005_review2", "T006_review3"],
            metadata={"user_request": user_request}
        ))
        
        # Task 8: Verification
        self.add_task(Task(
            task_id="T008_verify",
            task_type="verification",
            description="Verify docs match code",
            assigned_role=AgentRole.VERIFIER,
            status=TaskStatus.PENDING,
            priority=5,
            dependencies=["T007_document"]
        ))
    
    def _create_full_workflow(self, user_request: str):
        """Create comprehensive workflow with all agent types"""
        
        # Phase 1: Planning
        self.add_task(Task(
            task_id="T001_clarify",
            task_type="clarification",
            description="Clarify requirements",
            assigned_role=AgentRole.CLARIFIER,
            status=TaskStatus.PENDING,
            priority=10,
            metadata={"user_request": user_request}
        ))
        
        self.add_task(Task(
            task_id="T002_architect",
            task_type="architecture",
            description="Design architecture",
            assigned_role=AgentRole.ARCHITECT,
            status=TaskStatus.PENDING,
            priority=9,
            dependencies=["T001_clarify"],
            metadata={"user_request": user_request}
        ))
        
        # Phase 2: Implementation
        self.add_task(Task(
            task_id="T003_code",
            task_type="coding",
            description="Implement code",
            assigned_role=AgentRole.CODER,
            status=TaskStatus.PENDING,
            priority=8,
            dependencies=["T002_architect"],
            metadata={"user_request": user_request}
        ))
        
        # Phase 3: Quality assurance (parallel)
        self.add_task(Task(
            task_id="T004_review",
            task_type="review",
            description="Code review",
            assigned_role=AgentRole.REVIEWER,
            status=TaskStatus.PENDING,
            priority=7,
            dependencies=["T003_code"],
            metadata={"user_request": user_request}
        ))
        
        self.add_task(Task(
            task_id="T005_security",
            task_type="security_audit",
            description="Security analysis",
            assigned_role=AgentRole.SECURITY,
            status=TaskStatus.PENDING,
            priority=7,
            dependencies=["T003_code"],
            metadata={"user_request": user_request}
        ))
        
        self.add_task(Task(
            task_id="T006_tests",
            task_type="test_generation",
            description="Generate tests",
            assigned_role=AgentRole.TESTER,
            status=TaskStatus.PENDING,
            priority=7,
            dependencies=["T003_code"],
            metadata={"user_request": user_request}
        ))
        
        # Phase 4: Optimization & Documentation
        self.add_task(Task(
            task_id="T007_optimize",
            task_type="optimization",
            description="Optimize code",
            assigned_role=AgentRole.OPTIMIZER,
            status=TaskStatus.PENDING,
            priority=6,
            dependencies=["T004_review", "T005_security"],
            metadata={"user_request": user_request}
        ))
        
        self.add_task(Task(
            task_id="T008_document",
            task_type="documentation",
            description="Generate documentation",
            assigned_role=AgentRole.DOCUMENTER,
            status=TaskStatus.PENDING,
            priority=6,
            dependencies=["T003_code", "T006_tests"],
            metadata={"user_request": user_request}
        ))
        
        # Phase 5: Final verification
        self.add_task(Task(
            task_id="T009_verify",
            task_type="verification",
            description="Verify docs match code",
            assigned_role=AgentRole.VERIFIER,
            status=TaskStatus.PENDING,
            priority=5,
            dependencies=["T008_document"]
        ))
    
    def _create_review_workflow(self, code: str):
        """Create workflow for reviewing existing code"""
        
        # FIXED: Store code in context
        self.state["context"]["code_to_review"] = code
        
        review_types = [
            ("correctness", AgentRole.REVIEWER),
            ("security", AgentRole.SECURITY),
            ("performance", AgentRole.REVIEWER),
            ("style", AgentRole.REVIEWER)
        ]
        
        for i, (review_type, role) in enumerate(review_types, 1):
            self.add_task(Task(
                task_id=f"T00{i}_review_{review_type}",
                task_type=f"review_{review_type}",
                description=f"Review: {review_type}",
                assigned_role=role,
                status=TaskStatus.PENDING,
                priority=10,
                metadata={"code": code, "review_focus": review_type}
            ))
    
    def _get_system_prompt(self, role: AgentRole, task_type: str) -> str:
        """Get system prompt for agent role and task type"""
        
        prompts = {
            AgentRole.ARCHITECT: """You are an expert software architect. Your role is to:
- Design solutions that MATCH the actual requirements (don't over-engineer)
- Choose the SIMPLEST approach that solves the problem
- Avoid unnecessary complexity, patterns, or frameworks
- Design for the stated use case, not imagined future needs
- Ensure the design can actually be implemented and tested

CRITICAL: If the requirements are simple, the architecture should be simple.
Don't add Singleton patterns, config files, or enterprise features unless explicitly required.

Provide clear, structured architecture documentation that matches the scope of the request.""",

            AgentRole.CLARIFIER: """You are a Requirements Clarification Agent. Your ONLY job is to ask questions.

CRITICAL INSTRUCTIONS:
1. Ask as many clarifying questions as needed to fully understand the requirements
   - Simple requests may need only 1-2 questions
   - Complex multi-component systems may need 8-10 questions
   - Don't pad with unnecessary questions, don't skip important ones
2. You MUST NOT provide solutions, code, or implementation details
3. You MUST NOT say the requirements are clear unless they truly are
4. Format your response EXACTLY as shown below

When analyzing a request, identify:
- Missing technical specifications
- Unclear input/output formats
- Ambiguous requirements
- Unspecified edge cases or error handling
- Missing dependencies or environment details

RESPONSE FORMAT (use this exact format):
CLARIFYING QUESTIONS:
1. [Specific question about missing requirement]
2. [Specific question about unclear specification]
3. [Specific question about assumptions or constraints]
4. [Additional question if needed]

ONLY if ALL requirements are crystal clear and complete, respond with:
STATUS: CLEAR - All requirements are well-defined.

Remember: Your job is to ASK QUESTIONS, not solve problems.""",

            AgentRole.CODER: """You are an expert programmer. Your role is to:
- Write code that WORKS correctly on the first try
- Test your code mentally before outputting it
- Include ONLY what's needed to meet the requirements
- Handle errors that can realistically occur
- Add comments explaining WHY, not WHAT
- Provide a simple usage example at the end

CRITICAL FILE STRUCTURE RULES:
1. If the architect specifies MULTIPLE FILES, you MUST create ALL of them
2. Output each file with a clear header: ### FILE: filename.py ###
3. Do NOT combine everything into one file unless that's what the architect designed
4. Each module/file the architect specifies MUST be created separately
5. Imports between your files must be correct (from module import X)

CRITICAL OUTPUT RULES:
1. Output ONLY valid, executable Python code
2. Do NOT include markdown code blocks (```) - use ### FILE: ### headers instead
3. Start each file directly with imports or docstring
4. Main entry point should have: if __name__ == "__main__":

CRITICAL QUALITY RULES:
1. Your code must be EXECUTABLE and CORRECT
2. Keep it SIMPLE - match complexity to requirements
3. Do not add unrequested features
4. Handle edge cases: None inputs, missing files, etc.
5. If external files are needed, handle their absence gracefully

EXAMPLE MULTI-FILE OUTPUT:
### FILE: parser.py ###
\"\"\"Parser module\"\"\"
def parse_data(x):
    return x

### FILE: main.py ###
\"\"\"Main entry point\"\"\"
from parser import parse_data

if __name__ == "__main__":
    print(parse_data("test"))

Focus on code that works correctly and follows the architect's file structure exactly.""",

            AgentRole.REVIEWER: """You are a code reviewer. Your role is to:
- Find BUGS - syntax errors, logic errors, missing imports, unhandled exceptions
- Verify code actually WORKS - trace through execution mentally
- Check if code matches requirements (not over-engineered, not under-engineered)
- Identify missing error handling for realistic failures
- Verify external dependencies are handled correctly

CRITICAL CHECKS:
1. Will this code run without errors? Test mentally.
2. What if required files don't exist? What if inputs are None/empty?
3. Does this match what the user asked for?
4. Are there syntax errors, typos, or undefined variables?
5. Will the code produce the expected output?

Return STATUS: APPROVED if code is correct and matches requirements.
Return STATUS: NEEDS_REVISION with SPECIFIC bugs/issues if found.

Be thorough - broken code getting through is a critical failure.""",

            AgentRole.TESTER: """You are a test engineer. Your role is to:
- Generate comprehensive test cases using pytest
- Include unit tests for each function/method
- Include edge case tests (None, empty, boundary values)
- Include error condition tests
- Provide clear test names that describe what's being tested

Output executable pytest test code that can be run immediately.
Include necessary imports and fixtures.""",

            AgentRole.OPTIMIZER: """You are a performance optimization expert. Your role is to:
- Analyze code for performance bottlenecks
- Suggest algorithmic improvements with specific code changes
- Optimize memory usage where possible
- Identify unnecessary operations

Provide specific, actionable optimization suggestions with code examples.""",

            AgentRole.DOCUMENTER: """You are a technical documentation writer. Your role is to:
- Generate clear, accurate README documentation
- Document ONLY what actually exists in the code
- Include installation instructions
- Provide usage examples that match the actual code
- List actual dependencies from the imports

CRITICAL RULES:
1. Do NOT describe features that don't exist
2. Do NOT reference files that don't exist
3. Base your documentation ONLY on the actual code provided
4. Use code examples that actually work with the provided code

Format as Markdown with sections:
# Project Name
## Description
## Installation
## Usage
## API Reference
## Examples""",

            AgentRole.DEBUGGER: """You are a debugging specialist. Your role is to:
- Analyze error messages and stack traces
- Identify root causes of bugs
- Provide specific fixes with code
- Explain why the bug occurred

Focus on actionable fixes, not general advice.""",

            AgentRole.SECURITY: """You are a security analyst. Your role is to:
- Identify security vulnerabilities (injection, XSS, path traversal, etc.)
- Check input validation and sanitization
- Verify proper error handling (no sensitive data in errors)
- Check for hardcoded credentials or secrets

Provide specific, actionable security recommendations with code fixes.""",

            AgentRole.VERIFIER: """You are a FINAL VERIFICATION AGENT.

Your job is to verify that documentation matches the actual code:

1. DOCUMENTATION ACCURACY
   - Check if README describes actual code structure
   - Verify all file paths mentioned actually exist
   - Ensure instructions are accurate

2. CODE COMPLETENESS
   - Verify all deliverables are present
   - Check if code matches documentation claims

3. USER ACCEPTANCE
   - Can a user follow the README and use this project?
   - Are setup instructions accurate?

OUTPUT FORMAT:
STATUS: [PASS/FAIL]

VERIFICATION RESULTS:
1. Documentation Accuracy: [PASS/FAIL]
2. Code Completeness: [PASS/FAIL]
3. User Acceptance: [PASS/FAIL]

ISSUES (if any):
- [List specific issues]

RECOMMENDATION: [APPROVE / REJECT - needs revision]"""
        }
        
        return prompts.get(role, "You are a helpful AI assistant.")
    
    def _build_user_message(self, task: Task) -> str:
        """Build user message with context for the task"""
        
        message_parts = [f"TASK: {task.description}\n"]
        
        # FIXED: Always include user request from context or metadata
        user_request = (
            task.metadata.get('user_request') or 
            self.state["context"].get("user_request", "")
        )
        if user_request:
            message_parts.append(f"USER REQUEST:\n{user_request}\n")
        
        # Add clarification context if available
        if 'clarification' in self.state["context"]:
            clarification = self.state["context"]['clarification']
            if clarification and clarification != "Requirements are clear and complete.":
                message_parts.append(f"\nCLARIFICATION:\n{clarification}\n")
        
        # Add code if in metadata (for reviews)
        if "code" in task.metadata:
            message_parts.append(f"\nCODE TO ANALYZE:\n{task.metadata['code']}\n")
        
        # Add revision feedback if present
        if "revision_feedback" in task.metadata:
            message_parts.append(f"\nREVIEW FEEDBACK TO ADDRESS:\n{task.metadata['revision_feedback']}\n")
            message_parts.append(f"\nORIGINAL CODE:\n{task.metadata.get('original_code', '')}\n")
        
        # Add context from dependent tasks
        if task.dependencies:
            message_parts.append("\nCONTEXT FROM PREVIOUS TASKS:")
            for dep_id in task.dependencies:
                dep_task = next((t for t in self.completed_tasks if t.task_id == dep_id), None)
                if dep_task and dep_task.result:
                    message_parts.append(f"\n[{dep_task.task_id} - {dep_task.assigned_role.value}]")
                    result = dep_task.result[:8000] + "..." if len(dep_task.result) > 8000 else dep_task.result
                    message_parts.append(result)
        
        # FIXED: For documenter, ensure code is included
        if task.task_type == "documentation":
            code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
            if code_task and code_task.result and "coding" not in str(task.dependencies):
                message_parts.append(f"\nACTUAL CODE TO DOCUMENT:\n{code_task.result}\n")
        
        # FIXED: For security audit, ensure code is included
        if task.task_type == "security_audit":
            code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
            if code_task and code_task.result:
                message_parts.append(f"\nCODE TO ANALYZE FOR SECURITY:\n{code_task.result}\n")
        
        # Add review focus if specified
        if "review_focus" in task.metadata:
            message_parts.append(f"\nFOCUS YOUR REVIEW ON: {task.metadata['review_focus']}")
        
        # Add reviewer number if specified
        if "reviewer_number" in task.metadata:
            message_parts.append(f"\nYou are reviewer #{task.metadata['reviewer_number']}")
        
        return "\n".join(message_parts)
    
    def _update_context(self, task: Task):
        """Update shared context with task results"""
        context_key = f"{task.task_type}_{task.assigned_role.value}"
        self.state["context"][context_key] = {
            "task_id": task.task_id,
            "result": task.result,
            "completed_at": task.completed_at
        }
        
        # Also store latest code separately for easy access
        if task.task_type == "coding" and task.result:
            self.state["context"]["latest_code"] = task.result
    
    def _get_verifier_prompt(self, task: Task) -> tuple[str, str]:
        """Generate prompt for verifier agent"""
        
        project_dir = self.state["project_info"].get("project_dir", "")
        project_name = os.path.basename(project_dir) if project_dir else "project"
        
        # Get documentation from completed tasks
        doc_task = next((t for t in self.completed_tasks if t.task_type == "documentation"), None)
        readme_content = doc_task.result if doc_task else ""
        
        # Get actual code
        code_task = next((t for t in self.completed_tasks if t.task_type == "coding"), None)
        code_content = code_task.result if code_task else ""
        
        # Build file inventory
        file_inventory = []
        if project_dir and os.path.exists(project_dir):
            for root, dirs, files in os.walk(project_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, project_dir)
                    file_inventory.append(rel_path)
        
        system_prompt = self._get_system_prompt(AgentRole.VERIFIER, "verification")
        
        user_message = f"""PROJECT: {project_name}

FILES IN PROJECT:
{chr(10).join(f"  • {f}" for f in file_inventory) if file_inventory else "  (files not yet saved)"}

README CONTENT:
{readme_content[:4000] if readme_content else "No README found"}

ACTUAL CODE:
{code_content[:8000] if code_content else "No code found"}

Perform final verification. Does the README accurately describe the actual code?"""
        
        return system_prompt, user_message
    
    def _generate_workflow_report(self):
        """Generate and print workflow execution report"""
        print("\n" + "=" * 80)
        print("WORKFLOW EXECUTION REPORT")
        print("=" * 80)
        
        total_tasks = len(self.completed_tasks)
        successful = sum(1 for t in self.completed_tasks if t.status == TaskStatus.COMPLETED)
        failed = total_tasks - successful
        
        print(f"\n📊 Task Summary:")
        print(f"   Total tasks: {total_tasks}")
        print(f"   ✓ Successful: {successful}")
        print(f"   ✗ Failed: {failed}")
        
        if self.completed_tasks:
            completed_with_time = [t for t in self.completed_tasks if t.completed_at]
            if completed_with_time:
                total_time = max(t.completed_at for t in completed_with_time) - \
                            min(t.created_at for t in self.completed_tasks)
                print(f"   ⏱ Total time: {total_time:.2f}s")
        
        # Agent metrics
        print(f"\n📈 Agent Performance:")
        for agent_name, metrics in self.executor.metrics.items():
            success_rate = (metrics.successful_calls / metrics.total_calls * 100) if metrics.total_calls > 0 else 0
            print(f"   {agent_name}:")
            print(f"      Calls: {metrics.total_calls} (✓ {metrics.successful_calls}, ✗ {metrics.failed_calls})")
            print(f"      Success rate: {success_rate:.1f}%")
            print(f"      Avg response time: {metrics.avg_response_time:.2f}s")
            print(f"      Total tokens: {metrics.total_tokens}")
        
        # Task details
        print(f"\n📋 Task Details:")
        for task in self.completed_tasks:
            status_symbol = "✓" if task.status == TaskStatus.COMPLETED else "✗"
            duration = (task.completed_at - task.created_at) if task.completed_at else 0
            print(f"   {status_symbol} {task.task_id}: {task.description}")
            print(f"      Role: {task.assigned_role.value} | Duration: {duration:.2f}s")
            if task.error:
                print(f"      Error: {task.error}")
    
    def save_state(self, filename: Optional[str] = None):
        """Save workflow state to file"""
        project_dir = self.state.get("project_info", {}).get("project_dir")
        
        if filename is None:
            if project_dir:
                filename = os.path.join(project_dir, "session_state.json")
            else:
                filename = f"swarm_state_{self.state['workflow_id']}.json"
        
        # Serialize tasks properly
        def serialize_task(t: Task) -> dict:
            d = asdict(t)
            d['assigned_role'] = t.assigned_role.value
            d['status'] = t.status.value
            return d
        
        state_data = {
            "workflow_id": self.state["workflow_id"],
            "phase": self.state["phase"],
            "iteration": self.state["iteration"],
            "context": {k: v for k, v in self.state["context"].items() 
                       if not isinstance(v, dict) or 'result' not in v or len(str(v.get('result', ''))) < 10000},
            "history": self.state["history"],
            "project_info": self.state.get("project_info", {}),
            "completed_tasks": [serialize_task(t) for t in self.completed_tasks],
            "metrics": {k: asdict(v) for k, v in self.executor.metrics.items()}
        }
        
        with open(filename, 'w') as f:
            json.dump(state_data, f, indent=2, default=str)
        
        # Also save to sessions directory
        sessions_dir = "sessions"
        if not os.path.exists(sessions_dir):
            os.makedirs(sessions_dir)
        session_file = os.path.join(sessions_dir, f"swarm_state_{self.state['workflow_id']}.json")
        with open(session_file, 'w') as f:
            json.dump(state_data, f, indent=2, default=str)
    
    def get_metrics_summary(self) -> Dict:
        """Get summary of all metrics"""
        return {
            "agents": {k: asdict(v) for k, v in self.executor.metrics.items()},
            "tasks": {
                "total": len(self.completed_tasks),
                "completed": sum(1 for t in self.completed_tasks if t.status == TaskStatus.COMPLETED),
                "failed": sum(1 for t in self.completed_tasks if t.status == TaskStatus.FAILED)
            }
        }


def main():
    """Example usage"""
    coordinator = SwarmCoordinator()
    
    user_request = """
    Create a Python function that takes a list of numbers and returns:
    1. The median value
    2. The standard deviation
    3. Outliers (values > 2 std devs from mean)
    
    Include error handling for edge cases.
    """
    
    coordinator.run_workflow(user_request, workflow_type="standard")


if __name__ == "__main__":
    main()
