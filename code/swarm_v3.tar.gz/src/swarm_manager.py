#!/usr/bin/env python3
"""
Swarm Management Utility
Tools for monitoring, analyzing, and managing the swarm coordinator
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, List
import glob


class SwarmManager:
    """Manage and analyze swarm execution history"""
    
    def __init__(self):
        self.session_files = self._find_session_files()
    
    def _find_session_files(self) -> List[str]:
        """Find all session state files"""
        return sorted(glob.glob("swarm_state_*.json"), reverse=True)
    
    def list_sessions(self):
        """List all available sessions"""
        print("\n" + "=" * 80)
        print("AVAILABLE SWARM SESSIONS")
        print("=" * 80)
        
        if not self.session_files:
            print("\n⚠ No session files found")
            return
        
        for i, session_file in enumerate(self.session_files, 1):
            with open(session_file, 'r') as f:
                data = json.load(f)
            
            workflow_id = data.get('workflow_id', 'Unknown')
            total_tasks = len(data.get('completed_tasks', []))
            phase = data.get('phase', 'Unknown')
            
            print(f"\n{i}. {session_file}")
            print(f"   Workflow ID: {workflow_id}")
            print(f"   Phase: {phase}")
            print(f"   Tasks completed: {total_tasks}")
    
    def analyze_session(self, session_file: str):
        """Analyze a specific session"""
        print("\n" + "=" * 80)
        print(f"SESSION ANALYSIS: {session_file}")
        print("=" * 80)
        
        if not os.path.exists(session_file):
            print(f"\n❌ File not found: {session_file}")
            return
        
        with open(session_file, 'r') as f:
            data = json.load(f)
        
        # Basic info
        print(f"\nWorkflow ID: {data.get('workflow_id')}")
        print(f"Phase: {data.get('phase')}")
        print(f"Iteration: {data.get('iteration')}")
        
        # Task analysis
        tasks = data.get('completed_tasks', [])
        print(f"\n📊 Task Statistics:")
        print(f"   Total tasks: {len(tasks)}")
        
        by_status = {}
        by_role = {}
        for task in tasks:
            status = task.get('status')
            role = task.get('assigned_role')
            by_status[status] = by_status.get(status, 0) + 1
            by_role[role] = by_role.get(role, 0) + 1
        
        print("\n   By status:")
        for status, count in by_status.items():
            print(f"      {status}: {count}")
        
        print("\n   By agent role:")
        for role, count in sorted(by_role.items()):
            print(f"      {role}: {count}")
        
        # Agent metrics
        metrics = data.get('metrics', {})
        if metrics:
            print(f"\n📈 Agent Performance:")
            for agent_name, agent_metrics in sorted(metrics.items()):
                print(f"\n   {agent_name}:")
                print(f"      Total calls: {agent_metrics.get('total_calls', 0)}")
                print(f"      Success rate: {agent_metrics.get('successful_calls', 0)}/{agent_metrics.get('total_calls', 0)}")
                print(f"      Avg response time: {agent_metrics.get('avg_response_time', 0):.2f}s")
                print(f"      Total tokens: {agent_metrics.get('total_tokens', 0)}")
        
        # Timeline
        print(f"\n⏱ Task Timeline:")
        for task in tasks:
            task_id = task.get('task_id')
            role = task.get('assigned_role')
            status = task.get('status')
            duration = task.get('completed_at', 0) - task.get('created_at', 0)
            print(f"   {task_id} ({role}): {status} in {duration:.2f}s")
    
    def compare_sessions(self, file1: str, file2: str):
        """Compare two sessions"""
        print("\n" + "=" * 80)
        print("SESSION COMPARISON")
        print("=" * 80)
        
        try:
            with open(file1, 'r') as f:
                data1 = json.load(f)
            with open(file2, 'r') as f:
                data2 = json.load(f)
        except FileNotFoundError as e:
            print(f"\n❌ Error: {e}")
            return
        
        print(f"\nSession 1: {file1}")
        print(f"Session 2: {file2}")
        
        # Compare task counts
        tasks1 = len(data1.get('completed_tasks', []))
        tasks2 = len(data2.get('completed_tasks', []))
        print(f"\nTasks completed: {tasks1} vs {tasks2}")
        
        # Compare metrics
        metrics1 = data1.get('metrics', {})
        metrics2 = data2.get('metrics', {})
        
        all_agents = set(metrics1.keys()) | set(metrics2.keys())
        
        print("\nAgent comparison:")
        for agent in sorted(all_agents):
            m1 = metrics1.get(agent, {})
            m2 = metrics2.get(agent, {})
            
            calls1 = m1.get('total_calls', 0)
            calls2 = m2.get('total_calls', 0)
            time1 = m1.get('avg_response_time', 0)
            time2 = m2.get('avg_response_time', 0)
            
            print(f"\n   {agent}:")
            print(f"      Calls: {calls1} → {calls2} ({calls2 - calls1:+d})")
            print(f"      Avg time: {time1:.2f}s → {time2:.2f}s ({time2 - time1:+.2f}s)")
    
    def export_metrics(self, output_file: str = "swarm_metrics.csv"):
        """Export metrics to CSV"""
        print(f"\n📊 Exporting metrics to {output_file}...")
        
        import csv
        
        rows = []
        for session_file in self.session_files:
            with open(session_file, 'r') as f:
                data = json.load(f)
            
            workflow_id = data.get('workflow_id')
            metrics = data.get('metrics', {})
            
            for agent_name, agent_metrics in metrics.items():
                rows.append({
                    'workflow_id': workflow_id,
                    'agent': agent_name,
                    'total_calls': agent_metrics.get('total_calls', 0),
                    'successful_calls': agent_metrics.get('successful_calls', 0),
                    'failed_calls': agent_metrics.get('failed_calls', 0),
                    'avg_response_time': agent_metrics.get('avg_response_time', 0),
                    'total_tokens': agent_metrics.get('total_tokens', 0)
                })
        
        if not rows:
            print("⚠ No metrics data found")
            return
        
        with open(output_file, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        
        print(f"✓ Exported {len(rows)} metric records")
    
    def cleanup_old_sessions(self, keep_latest: int = 10):
        """Clean up old session files"""
        print(f"\n🧹 Cleaning up old sessions (keeping {keep_latest} latest)...")
        
        if len(self.session_files) <= keep_latest:
            print(f"✓ Only {len(self.session_files)} sessions found, nothing to clean")
            return
        
        to_delete = self.session_files[keep_latest:]
        
        print(f"\nFiles to delete ({len(to_delete)}):")
        for f in to_delete:
            print(f"   • {f}")
        
        confirm = input(f"\nDelete {len(to_delete)} files? [y/N]: ").strip().lower()
        if confirm == 'y':
            for f in to_delete:
                os.remove(f)
                print(f"   ✓ Deleted {f}")
            print(f"\n✓ Cleanup complete")
        else:
            print("❌ Cleanup cancelled")
    
    def generate_report(self, output_file: str = "swarm_report.txt"):
        """Generate comprehensive report"""
        print(f"\n📄 Generating report: {output_file}...")
        
        with open(output_file, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("SWARM COORDINATOR ANALYSIS REPORT\n")
            f.write("=" * 80 + "\n")
            f.write(f"\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total sessions analyzed: {len(self.session_files)}\n\n")
            
            # Aggregate statistics
            total_tasks = 0
            total_calls = 0
            agent_usage = {}
            
            for session_file in self.session_files:
                with open(session_file, 'r') as sf:
                    data = json.load(sf)
                
                tasks = data.get('completed_tasks', [])
                total_tasks += len(tasks)
                
                metrics = data.get('metrics', {})
                for agent_name, agent_metrics in metrics.items():
                    if agent_name not in agent_usage:
                        agent_usage[agent_name] = {
                            'calls': 0,
                            'tokens': 0,
                            'total_time': 0
                        }
                    
                    agent_usage[agent_name]['calls'] += agent_metrics.get('total_calls', 0)
                    agent_usage[agent_name]['tokens'] += agent_metrics.get('total_tokens', 0)
                    agent_usage[agent_name]['total_time'] += (
                        agent_metrics.get('avg_response_time', 0) * 
                        agent_metrics.get('total_calls', 0)
                    )
                    total_calls += agent_metrics.get('total_calls', 0)
            
            f.write(f"\nAGGREGATE STATISTICS:\n")
            f.write(f"   Total tasks executed: {total_tasks}\n")
            f.write(f"   Total agent calls: {total_calls}\n")
            
            f.write(f"\nAGENT USAGE:\n")
            for agent, stats in sorted(agent_usage.items(), key=lambda x: x[1]['calls'], reverse=True):
                f.write(f"\n   {agent}:\n")
                f.write(f"      Calls: {stats['calls']}\n")
                f.write(f"      Total tokens: {stats['tokens']}\n")
                f.write(f"      Total time: {stats['total_time']:.2f}s\n")
                if stats['calls'] > 0:
                    f.write(f"      Avg time/call: {stats['total_time']/stats['calls']:.2f}s\n")
        
        print(f"✓ Report saved to {output_file}")


def print_menu():
    """Print main menu"""
    print("\n" + "=" * 80)
    print("SWARM MANAGEMENT UTILITY")
    print("=" * 80)
    print("\n1. List all sessions")
    print("2. Analyze session")
    print("3. Compare sessions")
    print("4. Export metrics to CSV")
    print("5. Generate report")
    print("6. Cleanup old sessions")
    print("7. Exit")
    print()


def main():
    """Main entry point"""
    manager = SwarmManager()
    
    while True:
        print_menu()
        choice = input("Select option [1-7]: ").strip()
        
        if choice == '1':
            manager.list_sessions()
            
        elif choice == '2':
            manager.list_sessions()
            session_num = input("\nEnter session number (or filename): ").strip()
            
            try:
                if session_num.isdigit():
                    session_file = manager.session_files[int(session_num) - 1]
                else:
                    session_file = session_num
                
                manager.analyze_session(session_file)
            except (IndexError, ValueError):
                print("❌ Invalid selection")
        
        elif choice == '3':
            manager.list_sessions()
            file1 = input("\nFirst session (number or filename): ").strip()
            file2 = input("Second session (number or filename): ").strip()
            
            try:
                if file1.isdigit():
                    file1 = manager.session_files[int(file1) - 1]
                if file2.isdigit():
                    file2 = manager.session_files[int(file2) - 1]
                
                manager.compare_sessions(file1, file2)
            except (IndexError, ValueError):
                print("❌ Invalid selection")
        
        elif choice == '4':
            output = input("Output CSV file [swarm_metrics.csv]: ").strip()
            if not output:
                output = "swarm_metrics.csv"
            manager.export_metrics(output)
        
        elif choice == '5':
            output = input("Output report file [swarm_report.txt]: ").strip()
            if not output:
                output = "swarm_report.txt"
            manager.generate_report(output)
        
        elif choice == '6':
            keep = input("How many latest sessions to keep? [10]: ").strip()
            keep = int(keep) if keep.isdigit() else 10
            manager.cleanup_old_sessions(keep)
        
        elif choice == '7':
            print("\n👋 Goodbye!")
            break
        
        else:
            print("❌ Invalid option")
        
        input("\nPress Enter to continue...")


if __name__ == "__main__":
    main()
