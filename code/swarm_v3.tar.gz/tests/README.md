# Test Files

Add your test files here.

Example test structure:
```
tests/
├── test_coordinator.py
├── test_agents.py
└── test_workflows.py
```

## Running Tests

```bash
# If using pytest
pytest tests/

# Or just run individual test files
python3 tests/test_coordinator.py
```
